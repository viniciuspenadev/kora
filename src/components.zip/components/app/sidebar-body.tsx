"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname, useSearchParams } from "next/navigation"
import { logoutWithCleanup } from "@/lib/auth/logout"
import { useState, useEffect, useMemo, useRef, useLayoutEffect, useCallback } from "react"
import {
  LogOut, Inbox, Workflow, Contact, Settings, ChevronDown, ChevronRight, ChevronLeft, Briefcase,
  Bot, Bell, MessageSquare, CalendarDays,
  Wand2, BarChart3, Blocks, FileText,
  PanelLeftClose, PanelLeftOpen, Package, Boxes, ListChecks, Megaphone, Send, Funnel, Plus, Building2,
} from "lucide-react"
import { useAppShell } from "@/components/app/app-shell-context"
import { AnimatedLogoKoraVetor } from "@/components/app/logo-kora-vetor"

export interface PipelineMini { id: string; name: string; color: string; is_default: boolean }

interface NavLeaf {
  href:      string
  label:     string
  icon:      React.ReactNode
  soon?:     boolean
  adminOnly?: boolean
  /** Slug do módulo. Se setado e tenant não tem habilitado, item é escondido. Omitir = sempre visível (core). */
  module?:   string
  /** Capability granular (tenant_users): mostra pra owner/admin OU agente que tem essa capability. */
  capability?: string
  /** Só aparece se o tenant tem instância WhatsApp API Oficial (meta_cloud). */
  officialOnly?: boolean
  /** Sobrescreve a detecção de ativo (ex: itens com querystring que o pathname não pega). */
  activeOverride?: boolean
  hasUnread?: boolean
  /** "Funil de Vendas": link ao board + botão dedicado que expande os funis de venda ativos. */
  dealSwitcher?: boolean
}

interface NavGroup {
  key:        string
  label:      string
  icon:       React.ReactNode
  adminOnly?: boolean
  /** Capability granular (tenant_users): mostra o grupo pra owner/admin OU agente que a tem. */
  capability?: string
  module?:    string
  /** Só aparece se o tenant tem instância WhatsApp API Oficial (meta_cloud). */
  officialOnly?: boolean
  /** Abre painel FLYOUT ao lado do menu em vez do accordion (só no rail desktop). */
  flyout?:    boolean
  /** Filhos: leaves OU sub-grupos (accordion aninhado, ex: Templates dentro de Configurações). */
  children:   NavItem[]
}

type NavItem = NavLeaf | NavGroup

function isGroup(item: NavItem): item is NavGroup {
  return "children" in item
}

const subIcon = "w-4 h-4 shrink-0"

// Ícones de TOPO do rail ganham vida no hover da linha (group/item). Keyframes em
// globals.css. `topIcon` = "pop" com mola (padrão); `topIconSpin` = volta completa
// (usado onde girar faz sentido, ex: engrenagem de Configurações). Sub-ícones seguem
// estáticos (subIcon). transform-origin central pra girar/escalar centralizado.
const topIcon     = "w-5 h-5 shrink-0 origin-center group-hover/item:animate-[nav-icon-pop_0.5s_ease-out]"
const topIconSpin = "w-5 h-5 shrink-0 origin-center group-hover/item:animate-[nav-icon-spin_0.6s_ease-in-out]"

const NAV: NavItem[] = [
  { href: "/inbox",      label: "Inbox",      icon: <Inbox     className={topIcon} strokeWidth={1.75} />, module: "inbox"    },
  // ⚠️ O GRUPO "Atendimento" FOI DISSOLVIDO (2026-08-04, decisão do dono). Ele existia pra
  //    segurar dois filhos, e nenhum dos dois precisava dele:
  //      • "Pipelines" virou **Kanban** — é o nome que a pessoa usa pra essa tela, e
  //        "Pipelines" colidia com o funil de VENDAS lá em Negócios (duas coisas
  //        diferentes com o mesmo nome em menus vizinhos).
  //      • "Departamentos" saiu do menu e virou a 3ª lente DENTRO do próprio Kanban, ao
  //        lado de "Funil" e "Atendente" — que é onde ela sempre esteve tecnicamente
  //        (`groupBy=department`; a rota /atendimentos só reusava a mesma lente). Item de
  //        menu separado pra uma lente do mesmo quadro é a mesma tela contada duas vezes.
  //    Resultado: um acordeão a menos e uma tela de trabalho a um clique, não dois.
  //    A rota /atendimentos continua viva (links antigos seguem funcionando).
  { href: "/kanban", label: "Kanban", icon: <Workflow className={topIcon} strokeWidth={1.75} />, module: "kanban" },
  { href: "/contatos", label: "Contatos", icon: <Contact className={topIcon} strokeWidth={1.75} />, module: "contacts", capability: "contacts_access" },
  // Empresas (PJ, CRM F2) — tenant-wide por design. Gate = módulo "crm" só (sem
  // capability): paridade EXATA com a página (reads = módulo+tenant). Se um dia
  // quiser esconder de atendente comum, adicionar a MESMA capability aqui E no gate da página.
  { href: "/empresas", label: "Empresas", icon: <Building2 className={topIcon} strokeWidth={1.75} />, module: "crm" },
  {
    key:        "negocios",
    label:      "Negócios",
    icon:       <Briefcase className={topIcon} strokeWidth={1.75} />,
    // Grupo-CONTÊINER sem gate próprio (owner 2026-07-25): aparece se houver QUALQUER
    // filho visível — cada filho tem seu módulo+capability. Assim um atendente só de
    // Estoque/Catálogo ainda vê o item dele aqui, sem exigir acesso a Negócios.
    children: [
      { href: "/negocios/painel",    label: "Painel",          icon: <BarChart3 className={subIcon} strokeWidth={1.75} />, module: "crm", capability: "deals_manage" },
      { href: "/negocios/propostas", label: "Propostas",       icon: <FileText  className={subIcon} strokeWidth={1.75} />, module: "crm", capability: "deals_access" },
      // "Funil de Vendas" = link ao board + botão dedicado que expande os funis ativos.
      { href: "/negocios",        label: "Funil de Vendas", icon: <Funnel   className={subIcon} strokeWidth={1.75} />, module: "crm", capability: "deals_access", dealSwitcher: true },
      // Catálogo (serve Negócios e Estoque) + Estoque movidos pra CÁ (org do owner) —
      // cada um gateado pelo seu próprio módulo/capability (independentes de Negócios).
      { href: "/catalogo",        label: "Catálogo",        icon: <Package  className={subIcon} strokeWidth={1.75} />, module: "crm", capability: "catalog_access" },
      { href: "/estoque",         label: "Estoque",         icon: <Boxes    className={subIcon} strokeWidth={1.75} />, module: "inventory", capability: "inventory_access" },
    ],
  },
  {
    key:        "marketing",
    label:      "Marketing",
    icon:       <Megaphone className={topIcon} strokeWidth={1.75} />,
    module:     "broadcasts",
    capability: "marketing_access",   // owner/admin OU atendente com Ver+ de Marketing
    children: [
      { href: "/campanhas",            label: "Campanhas", icon: <Send       className={subIcon} strokeWidth={1.75} /> },
      { href: "/configuracoes/listas", label: "Listas",    icon: <ListChecks className={subIcon} strokeWidth={1.75} />, capability: "marketing_manage" },
    ],
  },
  { href: "/agenda",     label: "Agenda",     icon: <CalendarDays className={topIcon} strokeWidth={1.75} />, module: "agenda"  },
  { href: "/relatorios", label: "Relatórios", icon: <BarChart3    className={topIcon} strokeWidth={1.75} />, adminOnly: true },
  {
    key:   "automacao",
    label: "Automação",
    icon:  <Bot className={topIcon} strokeWidth={1.75} />,
    adminOnly: true,   // toda a automação pesada é só-admin (páginas gateiam owner/admin). Respostas rápidas sai daqui na P6.
    children: [
      // Aponta pra LISTA, não pro hub: /studio virou redirect (o hub morreu em 2026-07-30).
      // Link direto evita o salto extra e deixa o item do menu acender na página certa.
      { href: "/studio/fluxos",            label: "Kora Studio",           icon: <Blocks       className={subIcon} strokeWidth={1.75} />, module: "ai_studio"       },
      { href: "/automacao/mensagens",      label: "Mensagens automáticas", icon: <Bell         className={subIcon} strokeWidth={1.75} />, module: "welcome_message"  },
      { href: "/automacao/palavras-chave", label: "Palavras-chave",        icon: <Wand2        className={subIcon} strokeWidth={1.75} />, module: "keyword_triggers" },
      { href: "/configuracoes/respostas",  label: "Respostas rápidas",     icon: <MessageSquare className={subIcon} strokeWidth={1.75} />, module: "quick_replies"   },
      // ⚠️ "Fluxos de funil" (módulo `sequences`) REMOVIDO em 2026-08-05. Estava marcado
      //    `soon: true` e apontava pra `/automacao/funil` — **rota que nunca existiu**.
      //    Item de menu pra tela inexistente é promessa no cardápio sem prato na cozinha:
      //    ocupava espaço no menu, no catálogo do god mode e na vitrine do cliente.
      //    Quando sequências de follow-up existirem, nascem dentro de `broadcasts`.
    ],
  },
  // 🔴 ITEM ÚNICO, não mais acordeão (decisão do dono, 2026-07-30). Os ~15 itens de
  //    configuração migraram pro índice fixo da própria área (components/app/settings-nav
  //    + configuracoes/layout). Manter os dois seria o MESMO menu em dois lugares — e é
  //    assim que um lado ganha item novo e o outro fica desatualizado em silêncio.
  //    ⚠️ Ao adicionar tela de configuração, mexa no `SettingsNav`, não aqui.
  { href: "/configuracoes", label: "Configurações", icon: <Settings className={topIconSpin} strokeWidth={1.75} />, adminOnly: true },
]

interface Props {
  userName:        string
  userEmail:       string
  tenantName:      string
  userRole:        string
  enabledModules:  string[]
  /** Capabilities granulares do usuário (tenant_users): ex. ["inventory_access"]. */
  capabilities?:   string[]
  hasOfficial?:   boolean
  /** Drawer mobile / sidebar destravado aberto: labels sempre visíveis. */
  expanded?:       boolean
  /** Pipelines ativos → "Pipelines" vira sub-menu (switcher) quando há 2+. */
  pipelines?:      PipelineMini[]
  /** Funis de VENDA ativos → "Funil de Vendas" (Negócios) ganha expander (1+). */
  dealPipelines?:  PipelineMini[]
  /** Sidebar desktop recolhido (só ícones). Undefined = não é o rail desktop (drawer). */
  collapsed?:      boolean
  /** Alterna recolher/expandir (só desktop). */
  onToggleCollapse?: () => void
  /** Força expandir (ex: clicar num grupo estando recolhido). */
  onExpand?:       () => void
  /** Chamado ao navegar (fecha o drawer mobile). */
  onNavigate?:    () => void
}

/**
 * Corpo da navegação — compartilhado entre a Sidebar desktop (travável) e o
 * drawer mobile. Único lugar com a árvore de NAV, filtros de módulo/role,
 * active-state e badge de não-lidas. Suporta grupos aninhados (accordion dentro
 * de accordion — ex: Templates dentro de Configurações).
 */
export function SidebarBody({
  userName, userEmail, tenantName, userRole, enabledModules, capabilities, hasOfficial,
  pipelines, dealPipelines, expanded = false, collapsed = false, onToggleCollapse, onExpand, onNavigate,
}: Props) {
  const pathname              = usePathname()
  const searchParams          = useSearchParams()
  const [signing, setSigning] = useState(false)
  const { unread, unreadByPipeline, unreadWithoutPipeline } = useAppShell()
  const isAdminOrOwner        = ["owner", "admin"].includes(userRole)
  const modulesSet            = useMemo(() => new Set(enabledModules), [enabledModules])
  const capsSet               = useMemo(() => new Set(capabilities ?? []), [capabilities])

  // Labels: aparecem quando expandido; somem (opacity-0) quando recolhido. A
  // largura do rail (w-14, overflow-hidden) recorta o texto. Sem :hover.
  const reveal = expanded
    ? "opacity-100 transition-opacity duration-150"
    : "opacity-0"

  // Filtro recursivo: role (adminOnly) · canal oficial (officialOnly) · módulo.
  // Grupo sem filhos visíveis some junto.
  const filteredNav = useMemo(() => {
    const walk = (items: NavItem[]): NavItem[] =>
      items.flatMap<NavItem>((item) => {
        if (item.adminOnly && !isAdminOrOwner) return []
        if (item.officialOnly && !hasOfficial) return []
        // Capability granular: owner/admin sempre; agente só se tem a capability.
        if (item.capability && !isAdminOrOwner && !capsSet.has(item.capability)) return []
        if (isGroup(item)) {
          if (item.module && !modulesSet.has(item.module)) return []
          const kids = walk(item.children)
          return kids.length ? [{ ...item, children: kids }] : []
        }
        if (item.module && !modulesSet.has(item.module)) return []
        return [item]
      })
    return walk(NAV)
  }, [modulesSet, capsSet, hasOfficial, isAdminOrOwner])

  // Pipeline atual (pra destacar no sub-menu): SÓ quando se está no board (/kanban).
  // Fora dele (contatos, departamentos, etc.) nenhum pipeline fica ativo.
  const currentPipelineId = useMemo(() => {
    if (pathname !== "/kanban") return null
    if (!pipelines?.length) return null
    const q = searchParams.get("pipeline")
    if (q && pipelines.some((p) => p.id === q)) return q
    return (pipelines.find((p) => p.is_default) ?? pipelines[0]).id
  }, [pathname, pipelines, searchParams])

  // Funil de VENDA atual (destaque no sub-menu de Negócios): só no board /negocios.
  const currentDealPipelineId = useMemo(() => {
    if (pathname !== "/negocios") return null
    if (!dealPipelines?.length) return null
    const q = searchParams.get("pipeline")
    if (q && dealPipelines.some((p) => p.id === q)) return q
    return (dealPipelines.find((p) => p.is_default) ?? dealPipelines[0]).id
  }, [pathname, dealPipelines, searchParams])

  // Injeta pipelines como switcher (só com 2+ → vale a pena; 1 continua link direto).
  // Vale pros dois boards: atendimento (/kanban) e vendas (/negocios).
  const nav = useMemo(() => {
    // /negocios NÃO entra aqui: "Funil de Vendas" é link + expander dedicado (dealSwitcher).
    const switchers = [
      { targetHref: "/kanban", key: "pipelines", list: pipelines, currentId: currentPipelineId, toHref: (p: PipelineMini) => `/kanban?pipeline=${p.id}` },
    ].filter((s) => (s.list?.length ?? 0) > 1)
    if (!switchers.length) return filteredNav

    const inject = (items: NavItem[]): NavItem[] =>
      items.map((it) => {
        if (isGroup(it)) return { ...it, children: inject(it.children) }
        const sw = switchers.find((s) => s.targetHref === it.href)
        if (!sw) return it
        return {
          key:   sw.key,
          label: it.label,
          icon:  it.icon,
          children: (sw.list as PipelineMini[]).map((p) => ({
            href:  sw.toHref(p),
            label: p.name,
            icon:  (
              <span className="flex size-4 items-center justify-center">
                <span className="size-2 rounded-full" style={{ backgroundColor: p.color }} />
              </span>
            ),
            activeOverride: p.id === sw.currentId,
            hasUnread: (unreadByPipeline[p.id] ?? 0) +
              (p.id === (pipelines?.find(pipeline => pipeline.is_default) ?? pipelines?.[0])?.id ? unreadWithoutPipeline : 0) > 0,
          })),
        } as NavGroup
      })
    return inject(filteredNav)
  }, [filteredNav, pipelines, currentPipelineId, unreadByPipeline, unreadWithoutPipeline])

  const allHrefs = useMemo(() => {
    const out: string[] = []
    const walk = (items: NavItem[]) =>
      items.forEach((it) => (isGroup(it) ? walk(it.children) : out.push(it.href)))
    walk(NAV)
    return out
  }, [])

  function isLeafActive(href: string): boolean {
    if (!href) return false
    if (href === "/") return pathname === "/"
    if (pathname === href) return true
    if (!pathname.startsWith(href + "/")) return false
    const moreSpecific = allHrefs.find((h) =>
      h !== href && h.startsWith(href + "/") &&
      (pathname === h || pathname.startsWith(h + "/"))
    )
    return !moreSpecific
  }

  function isGroupActive(group: NavGroup): boolean {
    return group.children.some((c) => (isGroup(c) ? isGroupActive(c) : (c.activeOverride ?? isLeafActive(c.href))))
  }

  // Keys de todos os grupos (qualquer profundidade) que contêm o item ativo.
  function activeKeys(items: NavItem[]): string[] {
    const keys: string[] = []
    for (const it of items) {
      if (isGroup(it) && isGroupActive(it)) keys.push(it.key, ...activeKeys(it.children))
    }
    return keys
  }

  const [open, setOpen] = useState<Set<string>>(() => new Set(activeKeys(nav)))

  useEffect(() => {
    // Auto-abre o grupo do item ativo ao navegar (client nav não remonta o
    // SidebarBody, então o initializer do useState não roda de novo). Effect
    // intencional: deriva open-state do pathname mantendo o toggle manual.
    const ks = activeKeys(nav)
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (ks.length) setOpen((prev) => {
      const next = new Set(prev)
      ks.forEach((k) => next.add(k))
      return next
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  function toggleGroup(key: string) {
    setOpen((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  // ── Flyout (grupos com `flyout`, ex: Configurações) ─────────────────────
  // Abre um MENU DO MENU: segunda coluna de altura total, colada no rail — não
  // um popover (decisão do owner 2026-07-03). Só no rail desktop; no drawer
  // mobile cai pro accordion. No rail recolhido abre direto, sem expandir.
  const isDesktopRail = onToggleCollapse !== undefined
  const [flyoutKey, setFlyoutKey] = useState<string | null>(null)
  const flyoutRef = useRef<HTMLDivElement>(null)
  const [flyoutX, setFlyoutX] = useState(0)

  function openFlyout(key: string) {
    // Colado na borda direita do rail (flush) — parece extensão do próprio menu.
    setFlyoutX(navRef.current?.getBoundingClientRect().right ?? 56)
    setFlyoutKey(key)
  }

  useEffect(() => {
    if (!flyoutKey) return
    function onDown(e: MouseEvent) {
      const t = e.target as Element
      if (flyoutRef.current?.contains(t)) return
      if (t.closest?.("[data-flyout-trigger]")) return   // o toggle do botão cuida
      setFlyoutKey(null)
    }
    function onKey(e: KeyboardEvent) { if (e.key === "Escape") setFlyoutKey(null) }
    function onResize() { setFlyoutKey(null) }   // âncora (borda do rail) muda de lugar
    document.addEventListener("mousedown", onDown)
    document.addEventListener("keydown", onKey)
    window.addEventListener("resize", onResize)
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); window.removeEventListener("resize", onResize) }
  }, [flyoutKey])

  // Fecha ao recolher/expandir o rail (a âncora muda de lugar) e ao trocar de rota.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setFlyoutKey(null)
  }, [collapsed, pathname])

  // Clique num grupo top-level: flyout → painel lateral; senão, recolhido →
  // expande e abre; expandido → toggle accordion.
  function onGroupClick(key: string, flyout?: boolean) {
    if (flyout && isDesktopRail) {
      if (flyoutKey === key) setFlyoutKey(null)
      else openFlyout(key)
      return
    }
    if (!expanded) {
      onExpand?.()
      setOpen((prev) => new Set(prev).add(key))
    } else {
      toggleGroup(key)
    }
  }

  async function handleSignOut() {
    setSigning(true)
    await logoutWithCleanup({ redirectTo: "/auth/signin" })
  }

  // ── Indicador ativo deslizante ──────────────────────────────────────────
  // Um único realce que ESCORREGA (transform + transition) do item antigo até o
  // novo. Rastreia só o item TOP-LEVEL ativo (grupo ou leaf); itens aninhados
  // usam realce estático (bg-nav-active).
  const navRef     = useRef<HTMLElement>(null)
  const chipRefs   = useRef<Map<string, HTMLElement>>(new Map())
  const setChipRef = useCallback((key: string, el: HTMLElement | null) => {
    if (el) chipRefs.current.set(key, el); else chipRefs.current.delete(key)
  }, [])
  // `w`/`h` porque o realce mudou de tamanho FIXO pra tamanho do alvo: recolhido ele é o
  // quadrado do ícone; expandido, a linha inteira (ver measurePill).
  const [pill, setPill] = useState<{ x: number; y: number; w: number; h: number; show: boolean }>(
    { x: 0, y: 0, w: 36, h: 36, show: false },
  )
  // Borda direita do rail (x) — âncora da aba fixa "expandir funis" (segue collapse/expand).
  const [railRight, setRailRight] = useState(0)
  // Y do item "Funil de Vendas" — a aba fixa fica na MESMA altura dele (não no topo).
  const dealItemRef = useRef<HTMLAnchorElement | null>(null)
  const [dealItemY, setDealItemY] = useState<number | null>(null)
  const setDealItemEl = useCallback((el: HTMLAnchorElement | null) => { dealItemRef.current = el }, [])

  const activeKey = useMemo(() => {
    for (const item of nav) {
      if (isGroup(item)) { if (isGroupActive(item)) return item.key }
      else if (isLeafActive(item.href)) return item.href
    }
    return null
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nav, pathname])

  const measurePill = useCallback(() => {
    const navEl = navRef.current
    if (navEl) setRailRight(navEl.getBoundingClientRect().right)
    const de = dealItemRef.current?.getBoundingClientRect()
    setDealItemY(de && de.height > 0 ? de.top + de.height / 2 : null)
    const chip  = activeKey ? chipRefs.current.get(activeKey) : null
    if (!navEl || !chip) { setPill((p) => ({ ...p, show: false })); return }
    // 🔴 EXPANDIDO = realce na LINHA INTEIRA (pedido do dono). Antes o realce era sempre
    //    o quadrado de 36px do ícone, então com a sidebar aberta parecia que só o ícone
    //    estava selecionado e o rótulo ao lado ficava órfão. Recolhido continua no ícone
    //    — ali a linha É o ícone, e alargar não teria o que cobrir.
    //    `closest` em vez de um segundo mapa de refs: o chip já vive dentro do <a>/<button>
    //    da linha nos dois casos (leaf e grupo), então a linha é o pai natural dele.
    const row = expanded ? (chip.closest("a,button") as HTMLElement | null) ?? chip : chip
    const n = navEl.getBoundingClientRect(), c = row.getBoundingClientRect()
    setPill({
      x: c.left - n.left + navEl.scrollLeft,
      y: c.top  - n.top  + navEl.scrollTop,
      w: c.width, h: c.height, show: true,
    })
  }, [activeKey, expanded])

  // rAF loop (~280ms): re-mede a cada frame durante uma transição (largura do
  // sidebar / max-height do submenu) pra a bola SEGUIR o item que desliza.
  const rafRef = useRef(0)
  const loopMeasure = useCallback(() => {
    cancelAnimationFrame(rafRef.current)
    const start = performance.now()
    const tick = () => {
      measurePill()
      if (performance.now() - start < 280) rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
  }, [measurePill])

  // Medição imediata: mount · troca de página · expandir/recolher (drawer).
  useLayoutEffect(() => { measurePill() }, [measurePill, expanded])
  // Abrir/fechar grupo → segue a animação do submenu.
  useEffect(() => { loopMeasure() }, [open, loopMeasure])
  // Recolher/expandir o rail agora é ESTADO (não :hover) → segue a animação de largura.
  useEffect(() => { loopMeasure() }, [collapsed, loopMeasure])
  useEffect(() => {
    window.addEventListener("resize", measurePill)
    return () => { window.removeEventListener("resize", measurePill); cancelAnimationFrame(rafRef.current) }
  }, [measurePill])

  // ── Renderers de sub-nível (recursivos) ─────────────────────────────────
  function renderSubLeaf(sub: NavLeaf) {
    const active = sub.activeOverride ?? isLeafActive(sub.href)
    return (
      <Link
        key={sub.href}
        href={sub.soon ? "#" : sub.href}
        onClick={() => { if (!sub.soon) onNavigate?.() }}
        title={sub.hasUnread ? `${sub.label} · mensagens não lidas` : sub.label}
        className={`
          group/sub flex items-center gap-2.5 rounded-lg pl-2 pr-3 py-1.5 text-[13px] transition-colors overflow-hidden
          ${active
            ? "bg-nav-active text-nav-accent font-semibold"
            : sub.soon
            ? "text-nav-dim cursor-default"
            : "text-nav-dim hover:bg-nav-hover hover:text-nav-strong"
          }
        `}
      >
        <span className={`shrink-0 ${active ? "text-nav-accent" : sub.soon ? "text-nav-dim" : "text-nav-dim group-hover/sub:text-nav-text"}`}>
          {sub.icon}
        </span>
        <span className={`whitespace-nowrap flex-1 ${reveal}`}>{sub.label}</span>
        {sub.hasUnread && <span className={`size-2 rounded-full bg-red-500 shrink-0 ${reveal}`} role="img" aria-label="Mensagens não lidas" />}
        {sub.soon && (
          <span className={`whitespace-nowrap rounded-full bg-nav-hover px-1.5 py-0.5 text-[9px] font-semibold text-nav-dim uppercase tracking-wider ${reveal}`}>
            breve
          </span>
        )}
      </Link>
    )
  }

  // Link de um funil (na lista do flyout ou no accordion mobile) — ícone de funil.
  function renderPipeLink(p: PipelineMini, inFlyout: boolean) {
    const pActive = p.id === currentDealPipelineId
    return (
      <Link key={p.id} href={`/negocios?pipeline=${p.id}`}
        onClick={() => { if (inFlyout) setFlyoutKey(null); onNavigate?.() }} title={p.name}
        className={`group/sub flex items-center gap-2.5 rounded-lg ${inFlyout ? "px-2.5 py-2" : "pl-2 pr-3 py-1.5"} text-[13px] transition-colors overflow-hidden ${
          pActive ? "bg-nav-active text-nav-accent font-semibold" : "text-nav-text hover:bg-nav-hover hover:text-nav-strong"}`}>
        <Funnel className="size-4 shrink-0" strokeWidth={1.75} style={pActive ? undefined : { color: p.color }} />
        <span className={`whitespace-nowrap flex-1 ${inFlyout ? "" : reveal}`}>{p.name}</span>
      </Link>
    )
  }

  // "Funil de Vendas" = link pro board. No DESKTOP o menu dedicado dos funis é aberto
  // pela ABA FIXA na borda do rail (renderizada abaixo) — não por seta dentro do item.
  // No drawer MOBILE (sem flyout) fica o accordion inline com chevron. 0 funis = link.
  function renderDealSwitch(leaf: NavLeaf) {
    const list = dealPipelines ?? []
    if (list.length < 1) return renderSubLeaf(leaf)
    const active = isLeafActive(leaf.href)
    // Desktop: link simples (mesma cara dos outros), MAS com ref pra a aba fixa
    // se ancorar na altura dele. O toggle do menu dedicado é a aba na borda do rail.
    if (isDesktopRail) {
      return (
        <Link key={leaf.href} ref={setDealItemEl} href={leaf.href} onClick={() => onNavigate?.()} title={leaf.label}
          className={`group/sub flex items-center gap-2.5 rounded-lg pl-2 pr-3 py-1.5 text-[13px] transition-colors overflow-hidden ${
            active ? "bg-nav-active text-nav-accent font-semibold" : "text-nav-dim hover:bg-nav-hover hover:text-nav-strong"}`}>
          <span className={`shrink-0 ${active ? "text-nav-accent" : "text-nav-dim group-hover/sub:text-nav-text"}`}>{leaf.icon}</span>
          <span className={`whitespace-nowrap flex-1 ${reveal}`}>{leaf.label}</span>
        </Link>
      )
    }
    const isOpen = open.has("deal-pipes")
    return (
      <div key={leaf.href}>
        <div className={`group/sub flex items-center gap-1 rounded-lg pl-2 pr-1 py-0.5 transition-colors ${active ? "bg-nav-active" : "hover:bg-nav-hover"}`}>
          <Link href={leaf.href} onClick={() => onNavigate?.()} title={leaf.label}
            className="flex items-center gap-2.5 flex-1 min-w-0 py-1 text-[13px] overflow-hidden">
            <span className={`shrink-0 ${active ? "text-nav-accent" : "text-nav-dim group-hover/sub:text-nav-text"}`}>{leaf.icon}</span>
            <span className={`whitespace-nowrap flex-1 ${reveal} ${active ? "text-nav-accent font-semibold" : "text-nav-dim"}`}>{leaf.label}</span>
          </Link>
          <button type="button" onClick={() => toggleGroup("deal-pipes")} aria-expanded={isOpen} title="Funis de venda"
            className={`shrink-0 size-6 grid place-items-center rounded-md text-nav-dim hover:bg-nav-hover hover:text-nav-text transition-colors ${reveal}`}>
            <ChevronDown className={`size-3.5 transition-transform duration-200 ${isOpen ? "rotate-180 text-nav-accent" : ""}`} strokeWidth={2.5} />
          </button>
        </div>
        <div className={`overflow-hidden transition-[max-height,opacity] duration-200 ease-in-out ${isOpen && expanded ? "max-h-72 opacity-100" : "max-h-0 opacity-0"}`}>
          <div className="mt-0.5 mb-1 ml-4 pl-2.5 border-l border-nav-line space-y-0.5">
            {list.map((p) => renderPipeLink(p, false))}
          </div>
        </div>
      </div>
    )
  }

  // Leaf dentro do painel flyout — labels sempre visíveis (independe do rail).
  function renderFlyoutLeaf(sub: NavLeaf) {
    const active = sub.activeOverride ?? isLeafActive(sub.href)
    return (
      <Link
        key={sub.href}
        href={sub.soon ? "#" : sub.href}
        onClick={() => { if (!sub.soon) { setFlyoutKey(null); onNavigate?.() } }}
        title={sub.hasUnread ? `${sub.label} · mensagens não lidas` : sub.label}
        className={`flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] transition-colors ${
          active
            ? "bg-nav-active text-nav-accent font-semibold"
            : sub.soon
            ? "text-nav-dim cursor-default"
            : "text-nav-text hover:bg-nav-hover hover:text-nav-strong"
        }`}
      >
        <span className={`shrink-0 ${active ? "text-nav-accent" : sub.soon ? "text-nav-dim" : "text-nav-dim"}`}>{sub.icon}</span>
        <span className="flex-1 whitespace-nowrap">{sub.label}</span>
        {sub.hasUnread && <span className="size-2 rounded-full bg-red-500 shrink-0" role="img" aria-label="Mensagens não lidas" />}
        {sub.soon && (
          <span className="rounded-full bg-nav-hover px-1.5 py-0.5 text-[9px] font-semibold text-nav-dim uppercase tracking-wider">breve</span>
        )}
      </Link>
    )
  }

  function renderSubGroup(group: NavGroup) {
    const groupActive = isGroupActive(group)
    const isOpen      = open.has(group.key)
    return (
      <div key={group.key}>
        <button
          type="button"
          onClick={() => toggleGroup(group.key)}
          aria-expanded={isOpen}
          title={group.label}
          className="group/sub w-full flex items-center gap-2.5 rounded-lg pl-2 pr-3 py-1.5 text-[13px] transition-colors"
        >
          <span className={`shrink-0 ${groupActive ? "text-nav-accent" : "text-nav-dim group-hover/sub:text-nav-text"}`}>
            {group.icon}
          </span>
          <span className={`whitespace-nowrap flex-1 text-left ${reveal} ${groupActive ? "text-nav-accent font-semibold" : "text-nav-dim"}`}>
            {group.label}
          </span>
          <ChevronDown
            className={`size-3 text-nav-dim shrink-0 transition-transform duration-200 ${reveal} ${isOpen ? "rotate-180" : ""}`}
            strokeWidth={2.5}
          />
        </button>
        <div className={`overflow-hidden transition-[max-height,opacity] duration-200 ease-in-out ${isOpen && expanded ? "max-h-60 opacity-100" : "max-h-0 opacity-0"}`}>
          <div className="mt-0.5 mb-1 ml-4 pl-2.5 border-l border-nav-line space-y-0.5">
            {group.children.map((c) => (isGroup(c) ? renderSubGroup(c) : c.dealSwitcher ? renderDealSwitch(c) : renderSubLeaf(c)))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      <div className="flex items-center h-14 border-b border-nav-line px-2.5 shrink-0 overflow-hidden">
        {/* ── Logo: crossfade ícone curto ↔ SVG vetorizado (só opacity, GPU) ── */}
        <button
          type="button"
          onClick={collapsed ? onToggleCollapse : undefined}
          title={collapsed ? "Expandir menu" : undefined}
          className={`
            group/logo relative shrink-0 transition-[width] duration-200 ease-in-out
            ${collapsed ? "w-9 h-9 cursor-pointer" : "h-9 cursor-default"}
          `}
          style={collapsed ? undefined : { width: 78 }}
          tabIndex={collapsed ? 0 : -1}
        >
          {/* Ícone curto — 3D flip no hover quando recolhido */}
          <div
            className={`absolute inset-0 flex items-center justify-center transition-opacity duration-200 ease-in-out [perspective:600px] ${collapsed ? "opacity-100" : "opacity-0 pointer-events-none"}`}
          >
            <div className={`relative size-8 transition-transform duration-500 ease-out [transform-style:preserve-3d] ${collapsed ? "group-hover/logo:[transform:rotateY(180deg)]" : ""}`}>
              <span className="absolute inset-0 flex items-center justify-center [backface-visibility:hidden]">
                <Image
                  src="/logo_kora_curto.png"
                  alt="Kora"
                  width={32}
                  height={32}
                  priority
                  className="size-8 rounded-lg shadow-sm shadow-primary/20"
                />
              </span>
              <span className="absolute inset-0 flex items-center justify-center [backface-visibility:hidden] [transform:rotateY(180deg)]">
                <PanelLeftOpen className="size-5 text-nav-accent" strokeWidth={2} />
              </span>
            </div>
          </div>

          {/* SVG vetorizado animado — aparece quando expandido */}
          <div
            className={`absolute inset-0 flex items-center ml-3 transition-opacity duration-200 ease-in-out ${collapsed ? "opacity-0 pointer-events-none" : "opacity-100"}`}
          >
            <AnimatedLogoKoraVetor style={{ height: 28, width: 'auto' }} />
          </div>
        </button>

        {/* Spacer */}
        <div className="flex-1 min-w-0" />

        {expanded && onToggleCollapse && (
          <button
            type="button"
            onClick={onToggleCollapse}
            title="Recolher menu"
            className={`shrink-0 flex size-7 items-center justify-center rounded-lg text-nav-dim hover:text-nav-text hover:bg-nav-hover transition-colors ${reveal}`}
          >
            <PanelLeftClose className="size-4" strokeWidth={2} />
          </button>
        )}
      </div>

      <nav ref={navRef} className="scrollbar-none relative flex flex-col gap-1 flex-1 overflow-y-auto overflow-x-hidden px-2.5 py-3">
        {/* Realce deslizante — escorrega até o item ativo. Fica atrás dos ícones. */}
        <span
          aria-hidden
          // `transition-[transform,width,height]` e não `transition-all`: `all` faria a
          // opacidade animar junto e o realce piscaria ao trocar de página.
          className="pointer-events-none absolute left-0 top-0 rounded-xl bg-nav-active transition-[transform,width,height] duration-300 ease-out"
          style={{
            transform: `translate(${pill.x}px, ${pill.y}px)`,
            width: pill.w, height: pill.h,
            opacity: pill.show ? 1 : 0,
          }}
        />
        {nav.map((item) => {
          if (!isGroup(item)) {
            const active    = isLeafActive(item.href)
            // O pai Kanban não recebe badge; os indicadores ficam nos fluxos filhos.
            const showBadge = item.href === "/inbox" && unread > 0

            return (
              <Link
                key={item.href}
                href={item.soon ? "#" : item.href}
                onClick={() => { if (!item.soon) onNavigate?.() }}
                title={showBadge ? `${item.label} · mensagens não lidas` : item.label}
                className={`group/item relative flex items-center gap-3 rounded-xl py-1.5 pr-3 ${item.soon ? "cursor-default" : ""}`}
              >
                <span ref={(el) => setChipRef(item.href, el)} className={`
                  relative flex size-9 items-center justify-center rounded-xl shrink-0 transition-colors duration-150
                  ${active
                    ? "text-nav-accent"
                    : item.soon
                    ? "text-nav-dim"
                    : "text-nav-dim group-hover/item:bg-nav-hover group-hover/item:text-nav-strong"
                  }
                `}>
                  {item.icon}
                  {showBadge && (
                    <span className="absolute top-1 right-1 size-2.5 rounded-full bg-red-500 ring-2 ring-nav" aria-label="Mensagens não lidas" />
                  )}
                </span>
                <span className={`
                  whitespace-nowrap text-sm font-medium flex-1 ${reveal}
                  ${active ? "text-nav-accent" : item.soon ? "text-nav-dim" : "text-nav-text"}
                `}>
                  {item.label}
                </span>
                {showBadge && (
                  <span className={`size-2 rounded-full bg-red-500 shrink-0 ${reveal}`} aria-hidden />
                )}
                {item.soon && (
                  <span className={`whitespace-nowrap rounded-full bg-nav-hover px-1.5 py-0.5 text-[9px] font-semibold text-nav-dim uppercase tracking-wider ${reveal}`}>
                    breve
                  </span>
                )}
              </Link>
            )
          }

          const groupActive = isGroupActive(item)
          const asFlyout    = !!item.flyout && isDesktopRail
          const isOpen      = asFlyout ? flyoutKey === item.key : open.has(item.key)

          const groupButton = (
            <button
              type="button"
              onClick={() => onGroupClick(item.key, item.flyout)}
              aria-expanded={isOpen}
              title={item.label}
              data-flyout-trigger={asFlyout ? item.key : undefined}
              className={`group/item relative w-full flex items-center gap-3 rounded-xl py-1.5 pr-3 ${asFlyout && isOpen ? "bg-nav-hover" : ""}`}
            >
              <span ref={(el) => setChipRef(item.key, el)} className={`
                flex size-9 items-center justify-center rounded-xl shrink-0 transition-colors duration-150
                ${groupActive
                  ? "text-nav-accent"
                  : "text-nav-dim group-hover/item:bg-nav-hover group-hover/item:text-nav-strong"
                }
              `}>
                {item.icon}
              </span>
              <span className={`
                whitespace-nowrap text-sm font-medium flex-1 text-left ${reveal}
                ${groupActive ? "text-nav-accent" : "text-nav-text"}
              `}>
                {item.label}
              </span>
              {asFlyout ? (
                <ChevronRight
                  className={`size-3.5 shrink-0 transition-transform duration-200 ${reveal} ${isOpen ? "translate-x-0.5 text-nav-accent" : "text-nav-dim"}`}
                  strokeWidth={2.5}
                />
              ) : (
                <ChevronDown
                  className={`size-3.5 text-nav-dim shrink-0 transition-transform duration-200 ${reveal} ${isOpen ? "rotate-180" : ""}`}
                  strokeWidth={2.5}
                />
              )}
            </button>
          )

          const groupSubmenu = asFlyout ? null : (
            <div className={`overflow-hidden transition-[max-height,opacity] duration-200 ease-in-out ${isOpen && expanded ? "max-h-[34rem] opacity-100" : "max-h-0 opacity-0"}`}>
              <div className="my-1 ml-5 pl-3 border-l border-nav-line space-y-0.5">
                {item.children.map((c) => (isGroup(c) ? renderSubGroup(c) : c.dealSwitcher ? renderDealSwitch(c) : renderSubLeaf(c)))}
              </div>
            </div>
          )

          return (
            <div key={item.key}>
              {groupButton}
              {groupSubmenu}
            </div>
          )
        })}
      </nav>

      {/* MENU DO MENU — segunda coluna de altura total, colada no rail. `fixed`
          escapa o overflow-hidden do <aside> (sem transform no ancestral). */}
      {flyoutKey && isDesktopRail && (() => {
        // Menu DEDICADO dos funis de venda (2ª coluna) — botão "Novo funil" + lista.
        if (flyoutKey === "deal-pipes") {
          const list = dealPipelines ?? []
          return (
            <div
              ref={flyoutRef}
              style={{ left: flyoutX }}
              className="fixed inset-y-0 z-40 w-64 flex flex-col bg-nav border-r border-nav-line shadow-[12px_0_32px_-18px_rgba(15,23,42,0.25)] animate-in slide-in-from-left-4 fade-in-0 duration-150"
            >
              {/* setinha na borda EXTERNA — recolhe o menu dedicado (mesma altura do item) */}
              <button
                type="button"
                onClick={() => setFlyoutKey(null)}
                title="Recolher"
                style={{ top: dealItemY ?? 96 }}
                className="absolute -right-3 -translate-y-1/2 z-10 size-6 grid place-items-center rounded-full border border-nav-line bg-nav text-nav-dim shadow-sm hover:text-nav-text hover:border-nav-line transition-colors"
              >
                <ChevronLeft className="size-3.5" strokeWidth={2.5} />
              </button>
              <div className="flex items-center gap-2.5 h-14 px-4 border-b border-nav-line shrink-0">
                <span className="flex size-8 items-center justify-center rounded-lg bg-nav-active text-nav-accent shrink-0"><Funnel className="size-4" strokeWidth={1.75} /></span>
                <span className="text-sm font-bold text-nav-strong flex-1 truncate">Funis de Vendas</span>
              </div>
              <div className="p-2.5 border-b border-nav-line shrink-0">
                <Link
                  href="/negocios/funis"
                  onClick={() => { setFlyoutKey(null); onNavigate?.() }}
                  className="flex items-center justify-center gap-1.5 h-9 rounded-lg bg-primary hover:bg-primary-700 text-white text-xs font-semibold transition-colors"
                >
                  <Plus className="size-3.5" strokeWidth={2.5} /> Novo funil
                </Link>
              </div>
              <div className="scrollbar-none flex-1 overflow-y-auto px-2.5 py-2 space-y-0.5">
                {list.length === 0
                  ? <p className="px-2.5 py-6 text-xs text-nav-dim text-center">Nenhum funil ativo.</p>
                  : list.map((p) => renderPipeLink(p, true))}
              </div>
            </div>
          )
        }
        const g = nav.find((i): i is NavGroup => isGroup(i) && i.key === flyoutKey)
        if (!g) return null
        return (
          <div
            ref={flyoutRef}
            style={{ left: flyoutX }}
            className="fixed inset-y-0 z-40 w-64 flex flex-col bg-nav border-r border-nav-line shadow-[12px_0_32px_-18px_rgba(15,23,42,0.25)] animate-in slide-in-from-left-4 fade-in-0 duration-150"
          >
            {/* cabeçalho — espelha o do menu principal (h-14 + divisor) */}
            <div className="flex items-center gap-2.5 h-14 px-4 border-b border-nav-line shrink-0">
              <span className="flex size-8 items-center justify-center rounded-lg bg-nav-active text-nav-accent shrink-0">{g.icon}</span>
              <span className="text-sm font-bold text-nav-strong flex-1 truncate">{g.label}</span>
              <button
                type="button"
                onClick={() => setFlyoutKey(null)}
                title="Fechar"
                className="size-7 grid place-items-center rounded-lg text-nav-dim hover:text-nav-text hover:bg-nav-hover transition-colors shrink-0"
              >
                <PanelLeftClose className="size-4" strokeWidth={2} />
              </button>
            </div>

            <div className="scrollbar-none flex-1 overflow-y-auto px-2.5 py-3 space-y-0.5">
              {g.children.map((c) =>
                isGroup(c) ? (
                  <div key={c.key} className="pt-2 mt-2 border-t border-nav-line">
                    <p className="px-2.5 pb-1.5 text-[10px] font-bold uppercase tracking-widest text-nav-dim">{c.label}</p>
                    <div className="space-y-0.5">
                      {c.children.map((l) => (isGroup(l) ? null : renderFlyoutLeaf(l)))}
                    </div>
                  </div>
                ) : (
                  renderFlyoutLeaf(c)
                )
              )}
            </div>
          </div>
        )
      })()}

      {/* ABA FIXA na borda do rail — abre o menu dedicado dos funis. Sempre visível
          no contexto de Negócios (desktop) com o painel recolhido; "›" pra expandir. */}
      {isDesktopRail && (dealPipelines?.length ?? 0) > 0 && pathname === "/negocios" && flyoutKey !== "deal-pipes" && (
        <button
          type="button"
          data-flyout-trigger="deal-pipes"
          onClick={() => openFlyout("deal-pipes")}
          title="Funis de venda"
          style={{ left: railRight, top: dealItemY ?? 96 }}
          className="fixed z-30 -translate-x-1/2 -translate-y-1/2 flex size-6 items-center justify-center rounded-full border border-nav-line bg-nav text-nav-dim shadow-sm hover:text-nav-accent hover:border-primary-200 transition-colors animate-in fade-in-0 zoom-in-75 duration-150"
        >
          <ChevronRight className="size-3.5" strokeWidth={2.5} />
        </button>
      )}

      <div className="px-2.5 pb-3 pt-2 border-t border-nav-line shrink-0 overflow-hidden">
        <div className="flex items-center gap-1 py-1 overflow-hidden">
          <Link
            href="/configuracoes/perfil"
            onClick={() => onNavigate?.()}
            title="Meu perfil"
            className="group/profile flex items-center gap-2 min-w-0 flex-1 overflow-hidden rounded-lg hover:bg-nav-hover transition-colors"
          >
            <div className="flex size-9 items-center justify-center shrink-0">
              <ProfileAvatar name={userName} />
            </div>
            <div className={`min-w-0 flex-1 overflow-hidden ${reveal}`}>
              <p className="text-xs font-semibold text-nav-text truncate whitespace-nowrap group-hover/profile:text-nav-strong">{userName}</p>
              <p className="text-[11px] text-nav-dim truncate whitespace-nowrap leading-none mt-0.5">{userEmail}</p>
            </div>
          </Link>
          <button
            type="button"
            onClick={handleSignOut}
            disabled={signing}
            title="Sair"
            className={`shrink-0 size-7 items-center justify-center rounded-lg text-nav-dim hover:text-nav-text hover:bg-nav-hover transition-colors disabled:opacity-30 ${expanded ? "flex" : "hidden"}`}
          >
            <LogOut className="size-3.5" />
          </button>
        </div>
      </div>
    </>
  )
}

/** Avatar do usuário na sidebar: tenta a foto (/api/me/avatar), cai pra inicial. */
function ProfileAvatar({ name }: { name: string }) {
  const [err, setErr] = useState(false)
  if (err) {
    return (
      <div className="size-8 rounded-full bg-primary flex items-center justify-center ring-2 ring-nav shadow-sm shadow-primary/20">
        <span className="text-xs font-bold text-white">{name?.[0]?.toUpperCase() ?? "U"}</span>
      </div>
    )
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src="/api/me/avatar"
      alt=""
      onError={() => setErr(true)}
      className="size-8 rounded-full object-cover ring-2 ring-nav shadow-sm"
    />
  )
}
