"use client"

import { ConversationActionsButton, ConversationKanbanPosition, useConversationWorkflow, type WorkflowExtra } from "./conversation-workflow"
import { ContactPic } from "@/components/chat/contact-pic"

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react"
import { MessageBubble } from "./message-bubble"
import { MessageInput } from "./message-input"
import { MessageContextMenu } from "./message-context-menu"
import { formatPhoneDisplay } from "@/lib/phone-utils"
import { displayContactName, displayContactInitial } from "@/lib/contact"
import { getChannelPolicy } from "@/lib/channels/policy"
import { safeHref } from "@/lib/safe-href"
import { toast } from "sonner"
import {
  Phone, CheckCircle2, Clock, XCircle,
  RotateCcw, Loader2, Megaphone, ExternalLink, AlarmClock,
  ArrowLeft, Info,
} from "lucide-react"
import { SourceChip } from "@/components/chat/source-chip"
import { SourceLogo, channelToSource } from "@/components/chat/source-logo"
import { AgentAvatar } from "@/components/chat/agent-avatar"
import type { TransferOpts } from "@/components/chat/transfer-dialog"
import { FollowUpDialog } from "@/components/chat/followup-dialog"
import { followUpChip } from "@/lib/atendimento/followup-rules"
import { scheduleFollowUp, cancelFollowUp } from "@/lib/actions/followup"
import { NewAppointmentDialog } from "@/components/agenda/new-appointment-dialog"
import { listResources, listServices, type ResourceRow, type ServiceRow } from "@/lib/actions/agenda"
import { buildTimelineGroups, TimelineDivider, DateDivider } from "@/components/chat/timeline-divider"
import type { ChatMessage, ChatConversation, ChatQuickReply, ExternalAdReply } from "@/types/chat"
import { sanitizeAdReply } from "@/lib/ad-reply"
import { PlatformIcon, getPlatformMeta } from "@/components/ui/platform-icon"

interface Props {
  pipelines?: Array<{ id: string; name: string }>
  stages?: Array<{ id: string; name: string }>
  conversation: ChatConversation
  messages:     ChatMessage[]
  quickReplies: ChatQuickReply[]
  agents:       Array<{ id: string; full_name: string | null; department_id?: string | null }>
  departments:  Array<{ id: string; name: string; color: string }>
  onStatusChange: (status: string) => void
  onTransfer:     (opts: TransferOpts) => Promise<void>
  // Paginação de mensagens antigas (scroll-up)
  hasMoreOlder?:  boolean
  loadingOlder?:  boolean
  onLoadOlder?:   () => void
  /** Carga inicial das mensagens ao abrir a conversa → mostra skeleton. */
  loadingMessages?: boolean
  // Envio otimista — orquestrado em InboxClient
  onSendText:     (content: string, isPrivate: boolean) => Promise<void>
  onSendMedia:    (file: File, caption: string) => Promise<void>
  onSendVoice:    (file: File) => Promise<void>
  /** Responder/citar uma mensagem (define o alvo no composer). */
  onReply?:        (msg: ChatMessage) => void
  /** Reagir a uma mensagem com um emoji. */
  onReact?:        (msg: ChatMessage, emoji: string) => void
  /** Enviar localização (pin). */
  onSendLocation?: (loc: { latitude: number; longitude: number; name?: string; address?: string }) => Promise<void>
  /** Compartilhar contato (vCard). */
  onSendContact?:  (card: { name: string; phone: string }) => Promise<void>
  /** Enviar figurinha (webp). */
  onSendSticker?:  (file: File) => Promise<void>
  /** Mensagem citada ativa no composer (id = whatsapp_msg_id). */
  replyTarget?:    { id: string; preview: string; kind: string | null } | null
  onCancelReply?:  () => void
  onArchiveToggle: () => void
  /** Mobile (<md): volta pra lista de conversas. */
  onBack?:         () => void
  /** Mobile (<md): abre a ficha do contato (sheet). */
  onOpenContact?:  () => void
  /** Tenant tem o módulo agenda → habilita "Agendar" no menu da conversa. */
  agendaEnabled?:  boolean
  /** Follow-up marcado/cancelado — devolve o patch pro InboxClient atualizar a linha
   *  na hora (o chip da lista não espera o poll nem a varredura). */
  onFollowUpChange?: (patch: Partial<ChatConversation>) => void
}

const STATUS_OPTIONS = [
  { key: "open",     label: "Aberto",    icon: Clock,         color: "text-primary-700 bg-primary-50" },
  { key: "pending",  label: "Pendente",  icon: Clock,         color: "text-amber-600 bg-amber-50" },
  { key: "resolved", label: "Resolvido", icon: CheckCircle2,  color: "text-green-600 bg-green-50" },
  { key: "snoozed",  label: "Adiado",    icon: XCircle,       color: "text-slate-500 bg-slate-100" },
]

/** Tempo restante da janela de 24h, formatado curto (ex: "22h 14m", "47m"). */
function fmtWindowLeft(ms: number): string {
  const totalMin = Math.floor(ms / 60000)
  const h = Math.floor(totalMin / 60)
  const m = totalMin % 60
  return h > 0 ? `${h}h ${m}m` : `${m}m`
}

// Placeholder da thread enquanto a 1ª página de mensagens carrega (~130ms).
// Bolhas de larguras/lados variados pra parecer uma conversa real — evita o
// flash de "Nenhuma mensagem" no clique.
const SKELETON_ROWS = [
  { side: "left",  w: "w-40" }, { side: "left",  w: "w-56" },
  { side: "right", w: "w-48" }, { side: "left",  w: "w-32" },
  { side: "right", w: "w-60" }, { side: "right", w: "w-36" },
] as const

function MessageSkeleton() {
  return (
    <div className="space-y-3 py-2" aria-hidden="true">
      {SKELETON_ROWS.map((r, i) => (
        <div key={i} className={`flex ${r.side === "right" ? "justify-end" : "justify-start"}`}>
          <div
            className={`h-10 ${r.w} max-w-[70%] rounded-2xl bg-slate-200/70 animate-pulse ${
              r.side === "right" ? "rounded-br-sm" : "rounded-bl-sm"
            }`}
          />
        </div>
      ))}
    </div>
  )
}

export function ChatPanel({
  conversation, messages, quickReplies, agents, onStatusChange,
  hasMoreOlder = false, loadingOlder = false, onLoadOlder,
  loadingMessages = false,
  onSendText, onSendMedia, onSendVoice, onArchiveToggle,
  onReply, onReact, onSendLocation, onSendContact, onSendSticker, replyTarget, onCancelReply,
  onBack, onOpenContact, agendaEnabled = false, onFollowUpChange, pipelines = [], stages = [],
}: Props) {
  const workflow = useConversationWorkflow()
  const isArchived = !!conversation.archived_at
  // Menu de contexto (clique direito numa mensagem): responder/copiar/reagir/agendar/disparar fluxo.
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; msg: ChatMessage | null } | null>(null)
  // Follow-up: a promessa de voltar. Mesma regra do servidor (followup-rules).
  const [followUpOpen, setFollowUpOpen] = useState(false)
  const followUp = followUpChip(conversation)
  // Agendar pela conversa (módulo agenda) — carrega recursos/serviços on-demand.
  const [scheduleOpen, setScheduleOpen] = useState(false)
  const [agendaData, setAgendaData] = useState<{ resources: ResourceRow[]; services: ServiceRow[] } | null>(null)
  const [agendaLoading, setAgendaLoading] = useState(false)

  async function openSchedule() {
    if (!conversation.contact_id) return
    let data = agendaData
    if (!data) {
      setAgendaLoading(true)
      const [resources, services] = await Promise.all([listResources(), listServices()])
      data = { resources, services }
      setAgendaData(data)
      setAgendaLoading(false)
    }
    if (data.resources.length === 0) { toast.error("Configure os recursos da agenda primeiro (em Agenda → Configurar)."); return }
    setScheduleOpen(true)
  }
  const messagesEndRef     = useRef<HTMLDivElement>(null)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const topSentinelRef     = useRef<HTMLDivElement>(null)
  const prevConvIdRef      = useRef<string | null>(null)
  // Preservação de scroll position quando mensagens antigas são prepended
  const prependingRef               = useRef(false)
  const scrollFromBottomBeforeRef   = useRef(0)
  const prevMessagesLengthRef       = useRef(0)

  const contact = conversation.chat_contacts
  const name    = contact ? displayContactName(contact) : formatPhoneDisplay("")

  const currentStatus = STATUS_OPTIONS.find((s) => s.key === conversation.status) ?? STATUS_OPTIONS[0]

  // Header = canal do FIO (conversa), com fallback pra origem do contato — pós-merge
  // um contato tem fios de canais diferentes; cada conversa mostra o ícone do SEU canal.
  const channelSource = channelToSource(conversation.channel) ?? contact?.source ?? null

  // ── Janela de sessão — motor de política por canal (lib/channels/policy.ts) ──
  // Decide pelo CANAL da conversa (não pelo provider da instância — senão a janela da
  // WhatsApp Cloud vazava pra conversa de site pendurada na mesma instância oficial).
  const policy = getChannelPolicy(conversation.channel, conversation.whatsapp_instances?.provider)
  const hasWindow = policy.hasWindow
  // Âncora da janela = `last_inbound_at` da conversa (gravado do timestamp da Meta no
  // inbound — fonte autoritativa). Cross-check com a última msg inbound carregada cobre
  // o "chegou agora enquanto vejo" (antes do row refresh via realtime). Usa o mais recente.
  const lastInboundAt = useMemo(() => {
    let fromMsgs: string | null = null
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].sender_type !== "contact") continue
      // 🔴 NEM TODA mensagem de "contact" abre a janela do canal. O formulário do site
      //    grava uma mensagem de contato NO FIO DE WHATSAPP do cliente (o dedup é sem
      //    escopo de canal, de propósito) — e a janela de 24h da Meta só abre com
      //    mensagem que chegou PELO WhatsApp. Sem este filtro a tela dizia "janela
      //    aberta" com contagem regressiva, o servidor (`chat.ts`) dizia fechada, a
      //    atendente escrevia e levava erro. Duas verdades na mesma tela.
      // `counts_for_window: false` é o marcador genérico (vale pro próximo canal);
      // o `kind` cobre as linhas gravadas antes dele existir.
      const meta = messages[i].metadata as { counts_for_window?: boolean; kind?: string } | null | undefined
      if (meta?.counts_for_window === false || meta?.kind === "site_lead_answers") continue
      fromMsgs = messages[i].created_at; break
    }
    const fromConv = conversation.last_inbound_at ?? null
    if (fromConv && fromMsgs) return fromConv > fromMsgs ? fromConv : fromMsgs
    return fromConv ?? fromMsgs
  }, [messages, conversation.last_inbound_at])
  const [nowTick, setNowTick] = useState(() => Date.now())
  useEffect(() => {
    if (!hasWindow) return
    const id = setInterval(() => setNowTick(Date.now()), 60_000)
    return () => clearInterval(id)
  }, [hasWindow])
  const windowMsLeft = (hasWindow && lastInboundAt)
    ? policy.windowHours * 60 * 60 * 1000 - (nowTick - new Date(lastInboundAt).getTime())
    : null
  const windowOpen = !hasWindow ? true : (windowMsLeft !== null && windowMsLeft > 0)
  const windowClosed = hasWindow && !windowOpen && policy.outsideWindow === "template"
  // Janela fechada em canal SEM caminho de reabertura pago (Instagram/Messenger: a política
  // é "tag", não "template"). Antes isto não existia: `windowClosed` era falso, o composer
  // ficava normal, o atendente digitava e só o servidor recusava — atrito sem explicação.
  const windowNoReopen = hasWindow && !windowOpen && policy.outsideWindow !== "template"

  // Preservação de scroll quando msgs antigas são prepended.
  // Roda ANTES do paint pra evitar flicker.
  useLayoutEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return

    if (prependingRef.current) {
      // Restaura distância do fundo (msgs novas no topo, usuário fica na mesma msg)
      container.scrollTop = container.scrollHeight - scrollFromBottomBeforeRef.current
      prependingRef.current = false
    }

    prevMessagesLengthRef.current = messages.length
  }, [messages.length])

  // Auto-scroll: só dispara em (a) troca de conv ou (b) msg NOVA no fim.
  // Prepend de msgs antigas no topo NÃO ativa esse effect (newest stays the same).
  // Se usuário estiver lendo histórico (scrolled up), também NÃO empurra pra baixo.
  const lastMessageId = messages.length > 0 ? messages[messages.length - 1].id : null

  // Reações NÃO são entradas da timeline — colam na bolha-alvo (igual WhatsApp).
  // Separa as mensagens de reação, monta um mapa por whatsapp_msg_id-alvo e
  // colapsa pra ÚLTIMA reação de cada lado (cliente vs nós); emoji vazio = removida.
  const { timelineMessages, reactionsByTarget } = useMemo(() => {
    const normal: ChatMessage[] = []
    const latestPerSide = new Map<string, Map<"contact" | "agent", ChatMessage>>()
    for (const m of messages) {
      if (m.content_type !== "reaction") { normal.push(m); continue }
      const target = (m.metadata as { reacted_to_id?: string } | null)?.reacted_to_id
      if (!target) continue
      const side: "contact" | "agent" = m.sender_type === "contact" ? "contact" : "agent"
      const cur = latestPerSide.get(target)?.get(side)
      if (!cur || new Date(m.created_at) >= new Date(cur.created_at)) {
        if (!latestPerSide.has(target)) latestPerSide.set(target, new Map())
        latestPerSide.get(target)!.set(side, m)
      }
    }
    const map = new Map<string, { emoji: string; fromAgent: boolean }[]>()
    for (const [target, sides] of latestPerSide) {
      const arr: { emoji: string; fromAgent: boolean }[] = []
      for (const [side, m] of sides) {
        const emoji = (m.content ?? "").trim()
        if (emoji) arr.push({ emoji, fromAgent: side === "agent" })
      }
      if (arr.length) map.set(target, arr)
    }
    return { timelineMessages: normal, reactionsByTarget: map }
  }, [messages])

  // Nome do agente remetente resolvido pela lista `agents` (sender_id) — não pelo
  // join `profiles`, que NÃO vem nas mensagens de Realtime/otimistas (por isso o
  // nome só aparecia após sair e voltar na conversa = refetch com join).
  const agentsById = useMemo(() => {
    const m = new Map<string, string | null>()
    for (const a of agents) m.set(a.id, a.full_name)
    return m
  }, [agents])

  // Lookup p/ o menu de contexto: resolve a mensagem clicada (data-msg-id no DOM).
  const msgById = useMemo(() => new Map(timelineMessages.map((m) => [m.id, m])), [timelineMessages])

  const conversationActions: WorkflowExtra[] = [
    ...(agendaEnabled && conversation.contact_id ? [{ label: "Agendar", run: openSchedule, disabled: agendaLoading }] : []),
    { label: followUp ? "Follow-Up · alterar" : "Follow-Up", run: () => setFollowUpOpen(true) },
    ...(conversation.status !== "pending" ? [{ label: "Marcar pendente", run: () => onStatusChange("pending") }] : []),
    { label: isArchived ? "Restaurar conversa" : "Arquivar conversa", run: onArchiveToggle },
    ...(onOpenContact ? [{ label: "Ver contato", run: onOpenContact }] : []),
  ]

  // Clique direito em QUALQUER ponto do chat → menu de contexto. Se caiu numa
  // bolha (data-msg-id), traz as ações de mensagem; no vazio, só as da conversa.
  function openContextMenu(e: React.MouseEvent<HTMLDivElement>) {
    const el = (e.target as HTMLElement).closest("[data-msg-id]") as HTMLElement | null
    const msg = el?.dataset.msgId ? (msgById.get(el.dataset.msgId) ?? null) : null
    if (!msg && workflow) {
      setCtxMenu(null)
      workflow.menu(conversation, e, conversationActions)
      return
    }
    e.preventDefault()
    setCtxMenu({ x: e.clientX, y: e.clientY, msg })
  }

  useEffect(() => {
    const container = scrollContainerRef.current
    if (!container || !lastMessageId) return

    const newConv = prevConvIdRef.current !== conversation.id
    prevConvIdRef.current = conversation.id

    // "Está perto do fim?" — só rola se sim ou se conv mudou.
    const distFromBottom = container.scrollHeight - container.scrollTop - container.clientHeight
    const nearBottom     = distFromBottom < 200
    if (!newConv && !nearBottom) return

    function forceBottom() {
      if (!container) return
      container.scrollTop = container.scrollHeight
    }

    forceBottom()

    const mediaElements = container.querySelectorAll("img, video, audio")
    const cleanups: Array<() => void> = []

    mediaElements.forEach((el) => {
      const onLoad = () => forceBottom()
      el.addEventListener("load", onLoad)
      el.addEventListener("loadedmetadata", onLoad)
      el.addEventListener("error", onLoad)
      cleanups.push(() => {
        el.removeEventListener("load", onLoad)
        el.removeEventListener("loadedmetadata", onLoad)
        el.removeEventListener("error", onLoad)
      })
    })

    const t1 = setTimeout(forceBottom, 100)
    const t2 = setTimeout(forceBottom, 400)

    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
      cleanups.forEach((fn) => fn())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversation.id, lastMessageId])

  // IntersectionObserver no topo: dispara loadOlder quando sentinela entra na tela
  useEffect(() => {
    const sentinel = topSentinelRef.current
    if (!sentinel || !hasMoreOlder || !onLoadOlder) return

    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !loadingOlder) {
          // Captura distância do fim ANTES do prepend
          const container = scrollContainerRef.current
          if (container) {
            scrollFromBottomBeforeRef.current = container.scrollHeight - container.scrollTop
            prependingRef.current = true
          }
          onLoadOlder()
        }
      },
      { rootMargin: "100px" },
    )
    obs.observe(sentinel)
    return () => obs.disconnect()
  }, [hasMoreOlder, loadingOlder, onLoadOlder])

  // Nome do número que está atendendo esta conversa (B1) — só aparece se o tenant
  // deu um nome (display_name); número sem nome não polui o header.
  const numberName = conversation.whatsapp_instances?.display_name?.trim() || null

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <div className="flex items-center justify-between px-3 sm:px-5 py-3 bg-white border-b border-slate-200 shrink-0">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              aria-label="Voltar para conversas"
              className="md:hidden -ml-1 size-9 shrink-0 flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors"
            >
              <ArrowLeft className="size-5" />
            </button>
          )}
          <ContactPic
              pic={contact?.profile_pic_url}
              imgClass="size-10 rounded-full object-cover shrink-0"
              fallback={
                <div className="size-10 rounded-full bg-gradient-to-br from-white to-slate-200 ring-1 ring-inset ring-slate-200/70 flex items-center justify-center shrink-0">
                  <span className="text-sm font-bold text-slate-400">{contact ? displayContactInitial(contact) : "?"}</span>
                </div>
              }
            />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-900 truncate flex items-center gap-1.5">
              {name}
            </p>
            <div className="flex items-center gap-2 flex-wrap">
                  {numberName && (
                    <span
                      className="inline-flex items-center text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-primary-50 text-primary-700"
                      title="Você está atendendo por este número"
                    >
                      {numberName}
                    </span>
                  )}
                  {/* Status atual — só aparece quando NÃO é "Aberto" (estado normal não polui). */}
                  {conversation.status !== "open" && (
                    <span className={`inline-flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${currentStatus.color}`}>
                      <currentStatus.icon className="size-2.5" /> {currentStatus.label}
                    </span>
                  )}
                  {/* Promessa de retorno — clicável: o selo É o atalho pra mudar/cancelar. */}
                  {followUp && (
                    <button
                      type="button" onClick={() => setFollowUpOpen(true)} title={followUp.title}
                      className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full border transition-colors ${
                        followUp.tone === "due"
                          ? "bg-red-50 text-red-700 border-red-100 hover:bg-red-100"
                          : followUp.tone === "answered"
                            ? "bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100"
                            : "bg-primary-50 text-primary-700 border-primary-200 hover:bg-primary-100"
                      }`}
                    >
                      <AlarmClock className="size-2.5" /> {followUp.label}
                    </button>
                  )}
                  {/* Janela de 24h (só oficial) — movida do cluster de ações pra cá, alivia a barra. */}
                  {hasWindow && (windowOpen ? (
                    <span
                      className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${windowMsLeft! < 2 * 60 * 60 * 1000 ? "bg-amber-50 text-amber-700" : "bg-emerald-50 text-emerald-700"}`}
                      title="Janela de atendimento de 24h (WhatsApp Oficial). Dentro dela você responde com texto livre."
                    >
                      <Clock className="size-2.5" /> {fmtWindowLeft(windowMsLeft!)}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-500" title="Fora da janela de 24h — só dá pra enviar um template aprovado.">
                      <Clock className="size-2.5" /> Janela fechada
                    </span>
                  ))}
                  {/* Atribuída a (md+) — antes vinha do botão Transferir, que foi pro menu ⋮. */}
                  {conversation.assigned_to && (
                    <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-slate-500">
                      <AgentAvatar userId={conversation.assigned_to} name={conversation.profiles?.full_name} className="size-3.5" />
                      <span className="truncate max-w-[110px]">{conversation.profiles?.full_name ?? "Atribuída"}</span>
                    </span>
                  )}
                  {/* Origem: só no desktop — no mobile está na ficha "i" (lifecycle/telefone vivem no sidebar). */}
                  {channelSource && (
                    <span className="hidden md:inline-flex items-center gap-1">
                      <SourceLogo source={channelSource} size={14} />
                      <SourceChip source={channelSource} className="text-[10px]" />
                    </span>
                  )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {onOpenContact && <button type="button" onClick={onOpenContact} aria-label="Abrir detalhes do contato" title="Detalhes do contato" className="inline-flex size-8 items-center justify-center rounded-lg text-slate-500 hover:bg-primary-50 hover:text-primary focus-visible:ring-2 focus-visible:ring-primary"><Info className="size-4" /></button>}
          {/* Ação primária — Concluir (encerra) ou Reabrir se já resolvida.
              É o CTA que dispara o ciclo resolve→reopen→IA da Política de Atendimento. */}
          {conversation.status === "resolved" ? (
            <button
              type="button"
              onClick={() => onStatusChange("open")}
              title="Reabrir o atendimento"
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
            >
              <RotateCcw className="size-3.5" /> Reabrir
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onStatusChange("resolved")}
              title="Concluir o atendimento (encerra a conversa)"
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-primary text-white hover:bg-primary-700 transition-colors"
            >
              <CheckCircle2 className="size-3.5" /> Concluir
            </button>
          )}

          {/* Menu de ações secundárias — acessível em QUALQUER tela (fim do buraco
              de Transferir/Arquivar sumirem no mobile). */}
          <ConversationActionsButton conversation={conversation} extras={conversationActions} />
        </div>
      </div>

      <ConversationKanbanPosition conversation={conversation} pipelines={pipelines} stages={stages} />
      <AdSourceBanner ad={conversation.from_ad_meta} />

      <SiteSourceBanner conversation={conversation} />

      <div
        ref={scrollContainerRef}
        tabIndex={-1}
        onContextMenu={openContextMenu}
        className="flex-1 overflow-y-auto px-2 py-4"
        style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(0,0,0,0.03) 1px, transparent 0)", backgroundSize: "20px 20px" }}
      >
        {/* Sentinela do topo — dispara loadOlder ao entrar na tela */}
        {messages.length > 0 && (hasMoreOlder || loadingOlder) && (
          <div ref={topSentinelRef} className="flex items-center justify-center py-3">
            {loadingOlder ? (
              <Loader2 className="size-4 text-slate-300 animate-spin" />
            ) : (
              <span className="text-[10px] text-slate-300">Carregar mais antigas…</span>
            )}
          </div>
        )}
        {loadingMessages && messages.length === 0 ? (
          <MessageSkeleton />
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <Phone className="size-10 text-slate-200 mb-3" />
            <p className="text-sm font-medium text-slate-500 mb-1">Nenhuma mensagem</p>
            <p className="text-xs text-slate-400">As mensagens aparecerão aqui quando o contato enviar algo.</p>
          </div>
        ) : (
          buildTimelineGroups(timelineMessages).map((group) => (
            <section key={group.id} className="space-y-1">
              <DateDivider label={group.dateLabel} />
              {group.items.map((item) =>
                item.kind === "divider" ? (
                  <TimelineDivider key={item.id} icon={item.icon} label={item.label} time={item.time} />
                ) : (
                  <div key={item.id} id={`msg-${item.msg.id}`} data-msg-id={item.msg.id}>
                  <MessageBubble
                    message={item.msg}
                    agentName={item.msg.sender_type === "agent" ? (agentsById.get(item.msg.sender_id ?? "") ?? item.msg.profiles?.full_name) : null}
                    reactions={item.msg.whatsapp_msg_id ? reactionsByTarget.get(item.msg.whatsapp_msg_id) : undefined}
                    onReply={onReply}
                    onReact={onReact}
                    senderLabel={
                      item.msg.sender_type !== "contact"
                        ? null
                        : item.msg.group_participant_jid
                          ? formatPhoneDisplay(item.msg.group_participant_jid.split("@")[0])
                          : name
                    }
                  />
                  </div>
                )
              )}
            </section>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <MessageInput
        conversationId={conversation.id}
        quickReplies={quickReplies}
        disabled={conversation.status === "resolved"}
        windowClosed={windowClosed}
        windowNoReopen={windowNoReopen}
        channelLabel={policy.label}
        windowNeverOpened={windowClosed && !lastInboundAt}
        contactFirstName={name.split(/\s+/)[0] ?? ""}
        onSendText={onSendText}
        onSendMedia={onSendMedia}
        onSendVoice={onSendVoice}
        onSendLocation={onSendLocation}
        onSendContact={onSendContact}
        onSendSticker={onSendSticker}
        replyTarget={replyTarget}
        onCancelReply={onCancelReply}
      />

      {followUpOpen && (
      <FollowUpDialog
        onClose={() => setFollowUpOpen(false)}
        contactName={name}
        contactPic={contact?.profile_pic_url ?? null}
        current={conversation}
        ownerName={
          conversation.follow_up_by && conversation.follow_up_by !== conversation.assigned_to
            ? (agents.find((a) => a.id === conversation.follow_up_by)?.full_name ?? null)
            : null
        }
        onSave={async (dueAt, note) => {
          const r = await scheduleFollowUp(conversation.id, { dueAt, note })
          if ("error" in r) return r
          // Patch otimista: o selo e o chip da lista mudam no ato.
          onFollowUpChange?.({
            follow_up_at: dueAt, follow_up_note: note,
            follow_up_set_at: new Date().toISOString(), follow_up_fired_at: null,
          })
        }}
        onCancel={async () => {
          const r = await cancelFollowUp(conversation.id)
          if ("error" in r) return r
          onFollowUpChange?.({
            follow_up_at: null, follow_up_by: null, follow_up_note: null,
            follow_up_set_at: null, follow_up_fired_at: null,
          })
        }}
      />
      )}

      {scheduleOpen && agendaData && conversation.contact_id && (
        <NewAppointmentDialog
          resources={agendaData.resources}
          services={agendaData.services}
          fixedContact={{ id: conversation.contact_id, name }}
          conversationId={conversation.id}
          onClose={() => setScheduleOpen(false)}
          onCreated={() => { setScheduleOpen(false); toast.success("Agendamento criado") }}
        />
      )}

      {ctxMenu && (
        <MessageContextMenu
          x={ctxMenu.x}
          y={ctxMenu.y}
          message={ctxMenu.msg}
          conversationId={conversation.id}
          canTriggerFlow
          onReply={onReply}
          onReact={onReact}
          onSchedule={agendaEnabled && conversation.contact_id ? openSchedule : undefined}
          onClose={() => setCtxMenu(null)}
        />
      )}
    </div>
  )
}

/**
 * Banner compacto no topo do chat avisando que a conversa veio de um anúncio
 * Meta (Click-to-WhatsApp). Sempre visível enquanto a conv tá aberta — útil
 * pro atendente saber o contexto sem precisar abrir a sidebar.
 */
function AdSourceBanner({ ad: adRaw }: { ad: ExternalAdReply | null }) {
  const [thumbBroken, setThumbBroken] = useState(false)

  const ad = sanitizeAdReply(adRaw)
  if (!ad) return null

  const thumb = ad.thumbnailUrl
    ?? ad.originalImageUrl
    ?? (typeof ad.thumbnail === "string" ? `data:image/jpeg;base64,${ad.thumbnail}` : null)

  // Confia em sourceApp (literal da Meta) primeiro. Fallback pra inferir via URL.
  const app = ad.sourceApp?.toLowerCase()
  const platformKey =
      app === "instagram" || app === "facebook" || app === "messenger" || app === "whatsapp"
        ? app
        : ad.sourceUrl?.toLowerCase().includes("instagram") ? "instagram"
        : ad.sourceUrl?.toLowerCase().includes("facebook")  ? "facebook"
        : "meta"
  const platformMeta = getPlatformMeta(platformKey)

  return (
    <div className="flex items-center gap-2.5 px-4 py-2 bg-gradient-to-r from-primary-50 to-primary-50/40 border-b border-primary-100">
      <Megaphone className="size-4 text-primary-600 shrink-0" />
      {thumb && !thumbBroken && (
        /* eslint-disable-next-line @next/next/no-img-element */
        <img
          src={thumb}
          alt=""
          onError={() => setThumbBroken(true)}
          className="size-7 rounded object-cover shrink-0 border border-primary-200"
        />
      )}
      <div className="min-w-0 flex-1 flex items-center gap-2">
        <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider shrink-0" style={{ color: platformMeta.color }}>
          <PlatformIcon app={platformKey} size={12} />
          Anúncio {platformMeta.label}
        </span>
        {ad.title && (
          <span className="text-xs text-slate-700 truncate" title={ad.title}>
            · {ad.title}
          </span>
        )}
      </div>
      {ad.sourceUrl && (
        <a
          href={safeHref(ad.sourceUrl)}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[11px] font-semibold text-primary-700 hover:text-primary-900 inline-flex items-center gap-1 shrink-0"
          title="Abrir anúncio no Instagram/Facebook"
        >
          Ver criativo <ExternalLink className="size-3" />
        </a>
      )}
    </div>
  )
}

/**
 * Banner de continuidade site → WhatsApp. Exibe quando a conversa veio do
 * widget do site (channel='site' ou metadata.site_lead presente). Mostra
 * página de origem, UTMs e principais respostas do formulário — pra equipe
 * pegar contexto sem precisar abrir a sidebar.
 */
interface SiteLeadMeta {
  page_url?: string | null
  referrer?: string | null
  utm?: Record<string, string | null | undefined>
  journey?: string | null
  answers?: Record<string, string | null | undefined>
}

function SiteSourceBanner({ conversation }: { conversation: ChatConversation }) {
  const meta = conversation.metadata as Record<string, unknown> | null | undefined
  const siteLead = (meta?.site_lead ?? null) as SiteLeadMeta | null
  const isSite   = conversation.channel === "site"

  if (!siteLead && !isSite) return null

  // host limpo pra exibição (sem protocolo)
  const host = (() => {
    if (!siteLead?.page_url) return null
    try { return new URL(siteLead.page_url).host } catch { return siteLead.page_url }
  })()

  const utmSource = siteLead?.utm?.utm_source ?? null
  const intent    = siteLead?.answers?.intent ?? siteLead?.journey ?? null

  return (
    <div className="flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-sky-50/60 to-transparent border-b border-sky-100 text-[11px]">
      <SourceChip source="webform" label="Veio do site" />
      <div className="min-w-0 flex-1 flex items-center gap-2 text-slate-600">
        {host && (
          <span className="truncate" title={siteLead?.page_url ?? undefined}>
            {host}
          </span>
        )}
        {utmSource && (
          <span className="text-[10px] font-semibold text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded shrink-0">
            {utmSource}
          </span>
        )}
        {intent && (
          <span className="truncate" title={intent}>
            · {intent}
          </span>
        )}
      </div>
      {siteLead?.page_url && (
        <a
          href={safeHref(siteLead.page_url)}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[11px] font-semibold text-sky-700 hover:text-sky-900 inline-flex items-center gap-1 shrink-0"
          title="Abrir página de origem"
        >
          Abrir <ExternalLink className="size-3" />
        </a>
      )}
    </div>
  )
}
