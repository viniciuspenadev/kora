"use client"

import { useState, useEffect, useTransition, useCallback, useRef, useMemo } from "react"
import { useSearchParams, useRouter, usePathname } from "next/navigation"
import { ConversationWorkflowProvider } from "@/components/chat/conversation-workflow"
import { ConversationList } from "@/components/chat/conversation-list"
import { ChatPanel } from "@/components/chat/chat-panel"
import { ContactSidebar } from "@/components/chat/contact-sidebar"
import { ContactDetailsOverlay } from "@/components/chat/contact-details-overlay"
import { useConversationAccess } from "@/components/chat/use-conversation-access"
import { MessageCircle } from "lucide-react"
import { toast } from "sonner"
import Link from "next/link"
import {
  assignConversation,
  updateConversationStatus,
  markConversationRead,
  sendMessage,
  sendChatMedia,
  reactToMessage,
  sendLocationMessage,
  sendContactMessage,
  sendStickerMessage,
  archiveConversation,
  unarchiveConversation,
  setConversationFlagged,
  setConversationPinned,
  transferConversation,
} from "@/lib/actions/chat"
import type { TransferOpts } from "@/components/chat/transfer-dialog"
import {
  getConversations,
  getConversationsUpdates,
  getConversationById,
  getConversationViewCounts,
  type ConversationCursor,
  type ConversationFilters,
  type ConversationView,
  type ConversationViewCounts,
} from "@/lib/actions/conversations"
import {
  getMessages,
  getMessagesUpdates,
  type MessagesCursor,
} from "@/lib/actions/messages"
import { applyTag, removeTag } from "@/lib/actions/tags"
import { getRealtimeClient } from "@/lib/realtime"
import type {
  ChatConversation,
  ChatMessage,
  ChatContact,
  ChatQuickReply,
} from "@/types/chat"

interface PipelineMini   { id: string; name: string; color: string; is_default: boolean }
interface StageMini      { id: string; pipeline_id: string; name: string; color: string; position: number; is_won: boolean; is_lost: boolean }
interface TagMini        { id: string; name: string; color: string }
interface DepartmentMini { id: string; name: string; color: string }

interface Props {
  conversations:       ChatConversation[]
  messages:            Record<string, ChatMessage[]>
  contacts:            Record<string, ChatContact>
  quickReplies:        ChatQuickReply[]
  agents:              Array<{ id: string; full_name: string | null; department_id?: string | null }>
  instanceStatus:      string
  kanbanEnabled?: boolean
  pipelines?:          PipelineMini[]
  stages?:             StageMini[]
  tags?:               TagMini[]
  departments?:        DepartmentMini[]
  tagsByContact?:      Record<string, string[]>
  showChannel?:        boolean
  officialChannel?:    boolean
  initialCursor?:      ConversationCursor | null
  initialHasMore?:     boolean
  initialStatus?:      string
  initialViewCounts?:  ConversationViewCounts
  tenantId:            string
  currentUserId:       string
  userDepartmentId?:   string | null
  supabaseToken:       string
  agendaEnabled?:      boolean
}

const SEARCH_DEBOUNCE_MS = 300
// Realtime é o caminho primário. Poll fica como fallback (token expirou,
// WebSocket caiu, dropped events durante reconnect). 30s quando o WS está
// saudável; 5s no modo degradado (WS caído) pra não ficar 30s no escuro.
const POLL_INTERVAL_MS   = 30_000
const POLL_DEGRADED_MS   = 5_000
const STALE_MS           = 24 * 3600_000
/** Quanto o aviso "reusei/reabri a conversa" fica na tela — e na URL, que é a fonte dele. */
const DEDUP_NOTICE_MS    = 4_000

// Ordena por última mensagem (fallback created_at), desc. O server já entrega
// ordenado; isto mantém o topo após merges/inserts vindos do Realtime.
function sortByLastMessage(a: ChatConversation, b: ChatConversation): number {
  const da = a.last_message_at ?? a.created_at
  const db = b.last_message_at ?? b.created_at
  return new Date(db).getTime() - new Date(da).getTime()
}

interface ActiveFilters {
  viewFilter: ConversationView | null; currentUserId: string
  statusFilter: string; channelFilter: "" | "whatsapp" | "instagram" | "site"; pipelineFilter: string; agentFilter: string; departmentFilter: string; tagFilter: string
  staleOnly: boolean; fromAd: boolean; archivedOnly: boolean; searchDebounced: string
}

// Conversa nova (via Realtime INSERT) só entra na lista se casar com os filtros
// ATIVOS — mas só os "baratos" (resolvíveis client-side). search/tag exigem
// ILIKE/taggings no server → nesses casos deixamos o poll trazer.
function matchesActiveFilters(conv: ChatConversation, f: ActiveFilters): boolean {
  if (f.searchDebounced || f.tagFilter) return false            // resolve no server → poll
  if (f.archivedOnly || conv.archived_at) return false          // conv nova nunca é arquivada
  if (f.viewFilter === "all" && conv.status === "resolved") return false
  if (f.viewFilter === "mine" && (conv.status === "resolved" || conv.assigned_to !== f.currentUserId)) return false
  if (f.viewFilter === "waiting" && (conv.status === "resolved" || !isWaitingConversation(conv))) return false
  if (f.viewFilter === "unread" && (conv.status === "resolved" || conv.unread_count <= 0)) return false
  if (f.viewFilter === "resolved" && conv.status !== "resolved") return false
  if (f.viewFilter) return matchesSecondaryFilters(conv, f)
  // Aba Follow-up: conversa recém-criada nunca tem promessa (ela é sempre manual),
  // então nada entra por aqui — e o `status` não vale como filtro nessa aba.
  if (f.statusFilter === "followup") return false
  if (f.statusFilter && f.statusFilter !== "all" && conv.status !== f.statusFilter) return false
  return matchesSecondaryFilters(conv, f)
}

function isWaitingConversation(conv: ChatConversation): boolean {
  return conv.assigned_to === null && conv.ai_handling !== true
}

function matchesSecondaryFilters(conv: ChatConversation, f: ActiveFilters): boolean {
  if (f.channelFilter && conv.channel !== f.channelFilter) return false
  if (f.pipelineFilter && conv.pipeline_id !== f.pipelineFilter) return false
  if (f.agentFilter && conv.assigned_to !== f.agentFilter) return false
  if (f.departmentFilter && conv.department_id !== f.departmentFilter) return false
  if (f.fromAd && !conv.from_ad_meta) return false
  if (f.staleOnly && (!conv.last_message_at || new Date(conv.last_message_at).getTime() >= Date.now() - STALE_MS)) return false
  return true
}

export function InboxClient({
  conversations: initialConversations,
  contacts: initialContacts,
  quickReplies,
  agents,
  instanceStatus,
  kanbanEnabled = false,
  pipelines      = [],
  stages         = [],
  tags           = [],
  departments    = [],
  tagsByContact: initialTagsByContact = {},
  showChannel    = false,
  officialChannel = false,
  initialCursor       = null,
  initialHasMore      = false,
  initialStatus       = "all",
  initialViewCounts   = { all: 0, mine: 0, waiting: 0, unread: 0, resolved: 0 },
  tenantId,
  currentUserId,
  userDepartmentId = null,
  supabaseToken,
  agendaEnabled = false,
}: Props) {
  // ── State principal de listagem ─────────────────────────────
  const [conversations, setConversations] = useState(initialConversations)
  const [cursor, setCursor]               = useState<ConversationCursor | null>(initialCursor)
  const [hasMore, setHasMore]             = useState(initialHasMore)
  const [loadingMore, setLoadingMore]     = useState(false)
  const [loadingList, setLoadingList]     = useState(false)
  const [viewCounts, setViewCounts]       = useState(initialViewCounts)
  const [, setContacts]                   = useState(initialContacts)
  // Tags por contato — estado (não prop) pra permitir update otimista no
  // toggle da sidebar sem revalidar o RSC inteiro do /inbox.
  const [tagsByContact, setTagsByContact] = useState(initialTagsByContact)
  // Saúde do WebSocket do Realtime (canal da lista). true = caído/reconectando
  // → mostra aviso + acelera o poll. NÃO afeta recebimento (webhook→DB é
  // independente do navegador); é só a entrega ao vivo na tela deste atendente.
  const [realtimeDown, setRealtimeDown]   = useState(false)

  // ── Filtros (server-side) ───────────────────────────────────
  const [viewFilter, setViewFilter]         = useState<ConversationView | null>("all")
  const [statusFilter, setStatusFilter]     = useState(initialStatus)
  const [channelFilter, setChannelFilter]   = useState<"" | "whatsapp" | "instagram" | "site">("")
  const [pipelineFilter, setPipelineFilter] = useState("")
  const [agentFilter, setAgentFilter]       = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("")
  const [tagFilter, setTagFilter]           = useState("")
  const [staleOnly, setStaleOnly]           = useState(false)
  const [fromAd, setFromAd]                 = useState(false)
  const [archivedOnly, setArchivedOnly]     = useState(false)
  const [searchInput, setSearchInput]       = useState("")
  const [searchDebounced, setSearchDebounced] = useState("")

  // ── Conv ativa + msgs ───────────────────────────────────────
  const [activeId, setActiveId]                 = useState<string | null>(null)
  // Mobile: ficha do contato como sheet (no desktop é coluna fixa, sempre visível).
  const [contactSheetOpen, setContactSheetOpen] = useState(false)
  const [activeMessages, setActiveMessages]     = useState<ChatMessage[]>([])
  const [hasMoreOlder, setHasMoreOlder]         = useState(false)
  const [loadingOlder, setLoadingOlder]         = useState(false)
  const [loadingMsg, setLoadingMsg]             = useState(false)
  // Responder/citar: mensagem-alvo (id = whatsapp_msg_id) que o composer exibe.
  const [replyTarget, setReplyTarget]           = useState<{ id: string; preview: string; kind: string | null } | null>(null)
  const [, startTransition]                     = useTransition()

  // ── Refs ────────────────────────────────────────────────────
  const activeIdRef     = useRef<string | null>(null)
  const pollRef         = useRef<NodeJS.Timeout | null>(null)
  const abortRef        = useRef<AbortController | null>(null)
  const lastSyncRef     = useRef<string>(new Date().toISOString())
  const lastMsgSyncRef  = useRef<string>(new Date().toISOString())
  const lastCountsAtRef = useRef<number>(0)
  // Latest-ref do poll pra o callback de status do canal disparar reconciliação
  // sem entrar nas deps do effect (senão re-subscreveria a cada mudança de filtro).
  const pollFnRef       = useRef<() => void>(() => {})
  const wasDownRef      = useRef(false)
  const accessEpochRef = useRef(0)
  const accessAllowedRef = useRef(true)
  const [accessUnavailable, setAccessUnavailable] = useState(false)
  const replyTargetRef  = useRef<{ id: string; preview: string; kind: string | null } | null>(null)
  const searchParams    = useSearchParams()
  const router          = useRouter()
  const pathname        = usePathname()

  // Snapshot dos filtros pro handler do Realtime (canal não re-subscreve a cada
  // mudança de filtro — lê daqui).
  const filtersRef = useRef<ActiveFilters>({
    viewFilter, currentUserId, statusFilter, channelFilter, pipelineFilter, agentFilter, departmentFilter, tagFilter, staleOnly, fromAd, archivedOnly, searchDebounced,
  })
  // Latest-ref da lista pro handler do Realtime checar membership sem closure stale.
  const conversationsRef = useRef(conversations)

  /**
   * Sincroniza as refs de "último valor" — e este efeito é o PRIMEIRO do componente
   * DE PROPÓSITO.
   *
   * 🔴 POR QUE A ORDEM IMPORTA. Efeitos rodam na ordem em que são declarados. Estando
   *    aqui em cima, todo o resto do arquivo (deep-link, poll, os dois canais de Realtime)
   *    já lê o valor novo dentro do mesmo commit — que era exatamente a garantia que a
   *    escrita durante o render dava. Mover isto pra baixo quebra essa garantia em
   *    silêncio: o efeito de deep-link leria o `activeId` do render anterior.
   *
   * ⚠️ O QUE MUDA DE VERDADE: um callback ASSÍNCRONO (evento do WebSocket, timer) que
   *    caia na fresta entre pintar e este efeito rodar lê o valor do render anterior por
   *    alguns microssegundos. Todos os leitores aqui já são tolerantes — comparam e
   *    descartam quando não bate ("ainda estou nesta conversa?", "casa com os filtros?").
   *    O pior caso é um evento a mais buscado do servidor, nunca dado errado na tela.
   */
  useEffect(() => {
    activeIdRef.current = activeId
    replyTargetRef.current = replyTarget
    conversationsRef.current = conversations
    filtersRef.current = { viewFilter, currentUserId, statusFilter, channelFilter, pipelineFilter, agentFilter, departmentFilter, tagFilter, staleOnly, fromAd, archivedOnly, searchDebounced }
  })

  /**
   * Trocar de conversa cancela a citação pendente.
   *
   * ⚠️ Rastreador de "conversa anterior" em ESTADO, não em ref — mesmo idioma do composer
   *    ([message-input.tsx](src/components/chat/message-input.tsx) `seenConv`). Ajuste
   *    durante o render é o padrão que o próprio React prescreve pra isto; com ref, o
   *    valor lido no render vem de fora do fluxo do React e o resultado deixa de ser
   *    função do que está na tela.
   */
  const [replyConv, setReplyConv] = useState(activeId)
  if (replyConv !== activeId) {
    setReplyConv(activeId)
    if (replyTarget) setReplyTarget(null)
  }

  // ── Debounce search ─────────────────────────────────────────
  useEffect(() => {
    const t = setTimeout(() => setSearchDebounced(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  // ── Build filters object ────────────────────────────────────
  // A aba "Follow-up" não é um status — é um recorte por PROMESSA, que vale em
  // qualquer status. Por isso vira `followUpOnly` e libera o status no servidor.
  const buildFilters = useCallback((): ConversationFilters => ({
    view:         viewFilter ?? undefined,
    status:       viewFilter ? "all" : statusFilter === "followup" ? "all" : statusFilter,
    followUpOnly: (!viewFilter && statusFilter === "followup") || undefined,
    channel:      channelFilter || undefined,
    pipelineId:   pipelineFilter || undefined,
    agentId:      agentFilter    || undefined,
    departmentId: departmentFilter || undefined,
    tagId:        tagFilter      || undefined,
    staleOnly:    staleOnly || undefined,
    fromAd:       fromAd    || undefined,
    archivedOnly: archivedOnly || undefined,
    search:       searchDebounced || undefined,
  }), [viewFilter, statusFilter, channelFilter, pipelineFilter, agentFilter, departmentFilter, tagFilter, staleOnly, fromAd, archivedOnly, searchDebounced])

  // ── Fetch primeira página (chama em mudança de filtro) ──────
  const loadFirstPage = useCallback(async () => {
    // Aborta anterior
    abortRef.current?.abort()
    const ac = new AbortController()
    abortRef.current = ac

    setLoadingList(true)
    const accessEpoch = accessEpochRef.current
    try {
      const page = await getConversations({ filters: buildFilters(), cursor: null })
      if (ac.signal.aborted || accessEpoch !== accessEpochRef.current || !accessAllowedRef.current) return
      setConversations(page.conversations)
      setCursor(page.nextCursor)
      setHasMore(page.hasMore)
      lastSyncRef.current = new Date().toISOString()
    } catch (err) {
      if (!ac.signal.aborted) console.error("loadFirstPage:", err)
    } finally {
      if (!ac.signal.aborted) setLoadingList(false)
    }
  }, [buildFilters])

  // ── Load more (scroll infinito) ─────────────────────────────
  const loadMore = useCallback(async () => {
    if (!hasMore || loadingMore || !cursor) return
    setLoadingMore(true)
    const accessEpoch = accessEpochRef.current
    try {
      const page = await getConversations({ filters: buildFilters(), cursor })
      if (accessEpoch !== accessEpochRef.current || !accessAllowedRef.current) return
      setConversations((prev) => [...prev, ...page.conversations])
      setCursor(page.nextCursor)
      setHasMore(page.hasMore)
    } catch (err) {
      console.error("loadMore:", err)
    } finally {
      setLoadingMore(false)
    }
  }, [hasMore, loadingMore, cursor, buildFilters])

  useConversationAccess({
    ids: [...conversations.map(c => c.id), ...(activeId ? [activeId] : [])],
    onRevoked: ids => {
      accessEpochRef.current++
      const revoked = new Set(ids)
      setConversations(prev => prev.filter(c => !revoked.has(c.id)))
      if (activeIdRef.current && revoked.has(activeIdRef.current)) {
        activeIdRef.current = null
        setActiveId(null); setActiveMessages([]); setReplyTarget(null); setContactSheetOpen(false)
        toast.info("Seu acesso a esta conversa foi alterado.")
      }
    },
    onScopeChanged: () => { accessEpochRef.current++; void loadFirstPage() },
    onUnavailable: () => {
      accessAllowedRef.current = false
      accessEpochRef.current++; abortRef.current?.abort(); activeIdRef.current = null
      setConversations([]); setActiveId(null); setActiveMessages([]); setContactSheetOpen(false); setReplyTarget(null)
      setAccessUnavailable(true)
    },
    onRecovered: () => { accessAllowedRef.current = true; setAccessUnavailable(false); void loadFirstPage() },
  })

  // ── Polling (updates incrementais) ──────────────────────────
  const poll = useCallback(async () => {
    if (!accessAllowedRef.current) return
    try {
      const accessEpoch = accessEpochRef.current
      const since = lastSyncRef.current
      lastSyncRef.current = new Date().toISOString()
      const { conversations: updates } = await getConversationsUpdates({ since, filters: buildFilters() })
      if (accessEpoch !== accessEpochRef.current || !accessAllowedRef.current) return

      if (updates.length > 0) {
        setConversations((prev) => {
          const byId = new Map(prev.map((c) => [c.id, c]))
          for (const u of updates) byId.set(u.id, u)
          return Array.from(byId.values()).sort(sortByLastMessage)
        })
      }

      // Msgs novas/atualizadas da conv ativa — só busca o delta desde último sync
      if (activeIdRef.current) {
        const messageConversationId = activeIdRef.current
        const msgSince = lastMsgSyncRef.current
        lastMsgSyncRef.current = new Date().toISOString()
        const { messages: newMsgs } = await getMessagesUpdates({
          conversationId: messageConversationId,
          since:          msgSince,
        })
        if (newMsgs.length > 0 && activeIdRef.current === messageConversationId && accessEpoch === accessEpochRef.current && accessAllowedRef.current) {
          setActiveMessages((prev) => {
            const byId = new Map(prev.map((m) => [m.id, m]))
            for (const m of newMsgs) byId.set(m.id, m)
            return Array.from(byId.values()).sort(
              (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
            )
          })
        }
      }

      // Contadores globais das cinco lentes. No modo degradado o poll roda a cada
      // 5s, mas os counts continuam limitados a ~1x/30s.
      const nowMs = Date.now()
      if (nowMs - lastCountsAtRef.current >= POLL_INTERVAL_MS - 5_000) {
        lastCountsAtRef.current = nowMs
        setViewCounts(await getConversationViewCounts())
      }
    } catch {
      // silently — próximo poll tenta de novo
    }
  }, [buildFilters])

  useEffect(() => { pollFnRef.current = poll })

  // ── Refetch quando filtros mudam ────────────────────────────
  // Primeira renderização usa dados do SSR — pula. A partir do 2º render
  // (qualquer mudança de filtro/search), sempre refetcha.
  const isFirstMountRef = useRef(true)
  useEffect(() => {
    if (isFirstMountRef.current) {
      isFirstMountRef.current = false
      return
    }
    loadFirstPage()
  }, [viewFilter, statusFilter, channelFilter, pipelineFilter, agentFilter, departmentFilter, tagFilter, staleOnly, fromAd, archivedOnly, searchDebounced, loadFirstPage])

  // ── Carregar últimas 20 msgs ao selecionar conv ─────────────
  const loadMessages = useCallback(async (convId: string) => {
    try {
      const result = await getMessages({ conversationId: convId, limit: 20 })
      if (activeIdRef.current === convId) {
        setActiveMessages(result.messages)
        setHasMoreOlder(result.hasMore)
        lastMsgSyncRef.current = new Date().toISOString()
      }
    } catch (err) {
      console.error("Erro ao carregar mensagens:", err)
    }
  }, [])

  // ── Scroll up: carregar 20 anteriores ───────────────────────
  const loadOlderMessages = useCallback(async () => {
    if (!activeIdRef.current || !accessAllowedRef.current || loadingOlder || !hasMoreOlder) return
    const conversationId = activeIdRef.current
    const accessEpoch = accessEpochRef.current
    const oldest = activeMessages[0]
    if (!oldest) return
    setLoadingOlder(true)
    try {
      const result = await getMessages({
        conversationId,
        before:         { created_at: oldest.created_at, id: oldest.id },
        limit:          20,
      })
      if (activeIdRef.current === conversationId && accessAllowedRef.current && accessEpoch === accessEpochRef.current) {
        setActiveMessages((prev) => [...result.messages, ...prev])
        setHasMoreOlder(result.hasMore)
      }
    } catch (err) {
      console.error("Erro ao carregar msgs antigas:", err)
    } finally {
      setLoadingOlder(false)
    }
  }, [activeMessages, loadingOlder, hasMoreOlder])

  const handleSelect = useCallback((id: string) => {
    setActiveId(id)
    setContactSheetOpen(false)   // fecha a ficha ao trocar de conversa (mobile)
    setActiveMessages([])
    setHasMoreOlder(false)
    setLoadingMsg(true)

    // Só limpa o loading se ESTA conversa ainda é a ativa (evita apagar o
    // skeleton da conversa nova quando troca-se rápido A→B).
    loadMessages(id).finally(() => { if (activeIdRef.current === id) setLoadingMsg(false) })

    startTransition(async () => {
      await markConversationRead(id)
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id !== id) return c
          // A lente conta CONVERSAS não lidas, não a soma de mensagens.
          if (c.unread_count > 0) {
            setViewCounts((counts) => ({ ...counts, unread: Math.max(0, counts.unread - 1) }))
          }
          return { ...c, unread_count: 0, flagged_pending: false }
        })
      )
    })
  }, [loadMessages])

  /**
   * Banner "o modal reusou/reabriu uma conversa que já existia em vez de criar do zero".
   *
   * 🔴 LIDO DA URL, não copiado pra estado. Era: efeito lê a flag → grava no estado →
   *    limpa a URL → outro efeito zera o estado 4s depois. Duas cópias da mesma verdade e
   *    dois relógios pra mantê-las de acordo. Agora a URL é a única fonte, e **limpar a
   *    URL é o que faz o aviso sumir** — um relógio só, sem estado pra dessincronizar.
   *
   * ⚠️ CONSEQUÊNCIA VISÍVEL: a query fica na barra de endereço pelos 4 segundos do aviso
   *    (antes sumia na hora). Recarregar a página nesse intervalo reexibe o aviso — se
   *    corrige sozinho no próximo tique.
   */
  const dedupNotice: "reused" | "reopened" | null =
    searchParams.get("reopened") === "1" ? "reopened"
    : searchParams.get("reused") === "1" ? "reused"
    : null

  /**
   * Auto-seleciona a conversa que veio na querystring `?conversation=X` — do kanban, de
   * relatórios, de link colado, do modal "Nova conversa". Se ela não está na primeira
   * página (filtro/status diferente), busca por id e insere na lista.
   *
   * ⚠️ EXCEÇÃO CONSCIENTE a `set-state-in-effect` — a ÚNICA do arquivo, e não é preguiça.
   *
   *    O que o efeito faz é reagir a um sistema EXTERNO (o roteador): "chegou alguém
   *    pedindo a conversa X". É um evento de chegada, dispara uma vez, não é um laço de
   *    render. A regra não distingue isso de sincronização em cascata porque a leitura é
   *    síncrona em vez de vir num callback de assinatura.
   *
   *    🔴 TIRAR DE VERDADE exige uma DECISÃO DE PRODUTO, não uma reescrita: a conversa
   *       aberta teria que MORAR na URL (`activeId` derivado de `?conversation`, e clicar
   *       na lista viraria navegação). Ganha-se refresh que mantém a conversa e link
   *       compartilhável de verdade; **muda o botão Voltar**, que passaria a andar de
   *       conversa em conversa em vez de sair do inbox. Isso é escolha do dono.
   *
   *    Alternativas que PARECEM resolver e não resolvem: (a) resolver no server component
   *    e passar por prop — não cobre a navegação com a tela já aberta (o modal "Nova
   *    conversa" empurra a URL de dentro do próprio inbox, e reagir à prop nova pede
   *    exatamente este efeito de volta); (b) `key` pra remontar — jogaria fora a lista, as
   *    mensagens e o rascunho do atendente a cada deep-link.
   */
  useEffect(() => {
    const convParam = searchParams.get("conversation")
    if (!convParam || activeIdRef.current === convParam) return

    // Com aviso na tela, a limpeza da URL é do relógio do aviso (logo abaixo) — limpar
    // aqui apagaria o banner no mesmo instante em que ele aparece.
    const clearUrl = () => { if (!dedupNotice) router.replace(pathname, { scroll: false }) }

    const exists = conversations.find((c) => c.id === convParam)
    if (exists) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- exceção documentada no bloco acima
      handleSelect(convParam)
      clearUrl()
      return
    }

    // Não tá carregada: busca por ID e adiciona na lista
    let cancelled = false
    ;(async () => {
      try {
        const conv = await getConversationById(convParam)
        if (cancelled || !conv) return
        setConversations((prev) => {
          if (prev.some((c) => c.id === conv.id)) return prev
          return [conv, ...prev]
        })
        handleSelect(convParam)
      } catch (err) {
        console.error("Erro ao abrir conversa via ?conversation:", err)
      } finally {
        if (!cancelled) clearUrl()
      }
    })()

    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, conversations.length])

  // Relógio do banner: passados 4s a URL é limpa — e é isso que apaga o aviso.
  // Independente do efeito de deep-link acima de propósito: lá o efeito re-roda quando a
  // lista cresce, e um relógio amarrado a ele seria cancelado no meio (aviso eterno).
  useEffect(() => {
    if (!dedupNotice) return
    const t = setTimeout(() => router.replace(pathname, { scroll: false }), DEDUP_NOTICE_MS)
    return () => clearTimeout(t)
  }, [dedupNotice, router, pathname])

  // Polling — fallback. Realtime cobre 95% dos updates; poll pega o que escapou
  // (token expirado, WebSocket caiu, eventos perdidos durante reconnect).
  // Adaptativo: 30s com WS saudável, 5s quando caído (modo degradado).
  useEffect(() => {
    const interval = realtimeDown ? POLL_DEGRADED_MS : POLL_INTERVAL_MS
    pollRef.current = setInterval(poll, interval)
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [poll, realtimeDown])

  // ── Realtime: lista de conversas do tenant ──────────────────
  // Channel único por tenant — UPDATE/INSERT em chat_conversations chega
  // aqui. RLS aplica `tenant_id = app_tenant_id()`, então só rows do tenant
  // do JWT entram.
  useEffect(() => {
    if (!supabaseToken || !tenantId) return
    const client = getRealtimeClient(supabaseToken)
    // Evita setState após o cleanup (unsubscribe dispara CLOSED).
    let active = true

    const channel = client
      .channel(`list:${tenantId}`)
      .on(
        "postgres_changes",
        {
          event:  "*",
          schema: "public",
          table:  "chat_conversations",
          filter: `tenant_id=eq.${tenantId}`,
        },
        (payload) => {
          if (!accessAllowedRef.current) return
          const row = (payload.new ?? payload.old) as ChatConversation | undefined
          if (!row?.id) return

          // Conv já carregada: merge (preserva joins que o Realtime não traz).
          setConversations((prev) => {
            const idx = prev.findIndex((c) => c.id === row.id)
            if (idx < 0) return prev
            const merged = { ...prev[idx], ...row, chat_contacts: prev[idx].chat_contacts, profiles: prev[idx].profiles }
            const next = [...prev]
            next[idx] = merged
            return next.sort(sortByLastMessage)
          })

          // Conversa que entra na lista AO VIVO (fora dela hoje):
          //  • INSERT (conversa nova), OU
          //  • UPDATE que a tornou MINHA — atribuída a mim, ou na fila do MEU
          //    setor (não-atribuída + meu department_id), ou virei participante.
          //    Cobre "rotear/transferir pra departamento" subindo na hora.
          // Só busca se NÃO está na lista (UPDATE de conv já carregada é só
          // merge acima — evita fetch a cada mensagem). getConversationById
          // aplica visibilidade server-side (não vaza).
          const inList = conversationsRef.current.some((c) => c.id === row.id)
          const becameMine =
            row.assigned_to === currentUserId ||
            (row.assigned_to == null && !!userDepartmentId && row.department_id === userDepartmentId) ||
            (row.participants ?? []).includes(currentUserId)
          if (!inList && (payload.eventType === "INSERT" || (payload.eventType === "UPDATE" && becameMine))) {
            const accessEpoch = accessEpochRef.current
            getConversationById(row.id)
              .then((conv) => {
                if (!conv || !accessAllowedRef.current || accessEpoch !== accessEpochRef.current) return
                if (payload.eventType === "INSERT" && conv.status !== "resolved") {
                  setViewCounts((counts) => ({
                    ...counts,
                    all:     counts.all + 1,
                    mine:    counts.mine + (conv.assigned_to === currentUserId ? 1 : 0),
                    waiting: counts.waiting + (isWaitingConversation(conv) ? 1 : 0),
                    unread:  counts.unread + (conv.unread_count > 0 ? 1 : 0),
                  }))
                }
                if (!matchesActiveFilters(conv, filtersRef.current)) return
                setConversations((prev) => {
                  if (prev.some((c) => c.id === conv.id)) return prev
                  return [conv, ...prev].sort(sortByLastMessage)
                })
              })
              .catch((err) => console.error("Realtime fetch (entrou na lista):", err))
          }
        },
      )
      .subscribe((status) => {
        if (!active) return
        if (status === "SUBSCRIBED") {
          setRealtimeDown(false)
          // Reconexão: reconcilia o que escapou durante a queda (1 poll imediato).
          if (wasDownRef.current) {
            wasDownRef.current = false
            pollFnRef.current()
          }
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          wasDownRef.current = true
          setRealtimeDown(true)
        }
      })

    return () => {
      active = false
      channel.unsubscribe()
    }
  }, [supabaseToken, tenantId, currentUserId, userDepartmentId])

  // ── Realtime: mensagens da conv ATIVA ───────────────────────
  // Channel novo a cada troca de conv. RLS na `chat_messages` também filtra
  // por tenant_id; `conversation_id=eq.${activeId}` reduz pra só essa conv.
  useEffect(() => {
    if (!supabaseToken || !activeId) return
    const client = getRealtimeClient(supabaseToken)

    const channel = client
      .channel(`conv:${activeId}`)
      .on(
        "postgres_changes",
        {
          event:  "*",
          schema: "public",
          table:  "chat_messages",
          filter: `conversation_id=eq.${activeId}`,
        },
        (payload) => {
          const row = (payload.new ?? payload.old) as ChatMessage | undefined
          if (!row?.id || activeIdRef.current !== activeId) return

          setActiveMessages((prev) => {
            const idx = prev.findIndex((m) => m.id === row.id)
            if (idx < 0) {
              // Msg nova — dedup contra optimistic (status=pending, id temp-*)
              // que ainda não foi swap-ada. Match por content + sender + created_at proximate.
              const tempIdx = prev.findIndex((m) =>
                m.id.startsWith("temp-") &&
                m.sender_type === row.sender_type &&
                m.content === row.content &&
                Math.abs(new Date(m.created_at).getTime() - new Date(row.created_at).getTime()) < 30_000
              )
              if (tempIdx >= 0) {
                const next = [...prev]
                next[tempIdx] = { ...next[tempIdx], ...row, profiles: prev[tempIdx].profiles }
                return next
              }
              return [...prev, row].sort(
                (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
              )
            }
            // Update — preserva profiles join
            const next = [...prev]
            next[idx] = { ...next[idx], ...row, profiles: prev[idx].profiles }
            return next
          })
        },
      )
      .subscribe()

    return () => {
      channel.unsubscribe()
    }
  }, [supabaseToken, activeId])

  // ── Refresh do JWT Supabase ─────────────────────────────────
  // Não mora mais aqui: o relógio desceu pro singleton (`lib/realtime.ts`), porque o sino
  // de notificações usa o MESMO client em toda página e não renovava nada — com o token
  // curto (10min) ele morreria calado fora do inbox. Um timer por aba, não por componente.

  const activeConv = activeId ? conversations.find((c) => c.id === activeId) : null

  // Ad reply (CTWA) da 1ª msg do contato — compartilhado pelas duas instâncias
  // do ContactSidebar (coluna desktop + sheet mobile).
  const activeAdReply = useMemo(() => {
    const m = activeMessages.find((msg) =>
      msg.sender_type === "contact" &&
      (msg.metadata as { external_ad_reply?: unknown } | null)?.external_ad_reply
    )
    return ((m?.metadata as { external_ad_reply?: NonNullable<Parameters<typeof ContactSidebar>[0]["externalAdReply"]> } | null)
      ?.external_ad_reply) ?? null
  }, [activeMessages])

  // Trava o scroll do body enquanto o sheet de contato está aberto (mobile) —
  // senão o fundo rola atrás do painel fixo (jank no iOS).
  useEffect(() => {
    if (!contactSheetOpen || window.matchMedia("(min-width: 768px)").matches) return
    const prev = document.body.style.overflow
    document.body.style.overflow = "hidden"
    return () => { document.body.style.overflow = prev }
  }, [contactSheetOpen])

  // ── Envio otimista ──────────────────────────────────────────
  // Insere msg "fantasma" na UI antes de bater no server. Quando server
  // confirma (1-2s pra texto, 3-10s pra mídia), swap do id temp pelo real.
  // Em falha, marca como status=failed (bubble mostra ícone vermelho).
  const makeTempMessage = useCallback((opts: {
    content?: string | null
    contentType: ChatMessage["content_type"]
    isPrivateNote?: boolean
    mediaUrl?: string | null
    mediaMime?: string | null
    mediaFileName?: string | null
  }): ChatMessage => ({
    id:                    `temp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    conversation_id:       activeIdRef.current ?? "",
    tenant_id:             "",
    sender_type:           "agent",
    sender_id:             currentUserId,   // já carimba o autor → nome aparece na hora (otimista), sem esperar o refetch
    content_type:          opts.contentType,
    content:               opts.content ?? null,
    media_url:             opts.mediaUrl ?? null,
    media_mime_type:       opts.mediaMime ?? null,
    media_file_name:       opts.mediaFileName ?? null,
    whatsapp_msg_id:       null,
    reply_to_id:           null,
    status:                "pending",
    is_private_note:       opts.isPrivateNote ?? false,
    metadata:              {},
    group_participant_jid: null,
    edited_at:             null,
    deleted_at:            null,
    created_at:            new Date().toISOString(),
    profiles:              null,
  }), [currentUserId])

  const handleSendText = useCallback(async (content: string, isPrivate: boolean) => {
    const convId = activeIdRef.current
    if (!convId) return

    // Citação ativa (nota privada não cita pro WhatsApp).
    const reply = isPrivate ? null : replyTargetRef.current
    const temp = makeTempMessage({ content, contentType: "text", isPrivateNote: isPrivate })
    if (reply) temp.metadata = { quoted: { msg_id: reply.id, preview: reply.preview, kind: reply.kind, participant: null } }
    setActiveMessages((prev) => [...prev, temp])
    if (reply) setReplyTarget(null)

    // Reordena lista: conv enviada vai pro topo
    setConversations((prev) => {
      const next = prev.map((c) =>
        c.id === convId
          ? { ...c, last_message_at: temp.created_at, last_message_preview: content.slice(0, 100), last_message_dir: "out" as const }
          : c
      )
      return next.sort(sortByLastMessage)
    })

    try {
      const result = await sendMessage(convId, content, isPrivate, reply?.id)
      setActiveMessages((prev) =>
        prev.map((m) => m.id === temp.id ? { ...m, id: result.id, status: "sent" } : m)
      )
    } catch (err) {
      setActiveMessages((prev) =>
        prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m)
      )
      throw err
    }
  }, [makeTempMessage])

  const sendMediaInternal = useCallback(async (file: File, caption: string, isVoiceNote: boolean) => {
    const convId = activeIdRef.current
    if (!convId) return

    const blobUrl  = URL.createObjectURL(file)
    const mimeType = file.type
    const ctype: ChatMessage["content_type"] =
        mimeType.startsWith("image/") ? "image"
      : mimeType.startsWith("audio/") ? "audio"
      : mimeType.startsWith("video/") ? "video"
      : "document"

    const reply = replyTargetRef.current
    const temp = makeTempMessage({
      content:       caption || null,
      contentType:   ctype,
      mediaUrl:      blobUrl,
      mediaMime:     mimeType,
      mediaFileName: file.name,
    })
    if (isVoiceNote) temp.metadata = { ...temp.metadata, is_voice_note: true }
    if (reply) temp.metadata = { ...temp.metadata, quoted: { msg_id: reply.id, preview: reply.preview, kind: reply.kind, participant: null } }
    setActiveMessages((prev) => [...prev, temp])
    if (reply) setReplyTarget(null)

    setConversations((prev) => {
      const preview = caption || ({ image: "📷 Imagem", audio: isVoiceNote ? "🎤 Mensagem de voz" : "🎤 Áudio", video: "📹 Vídeo", document: "📎 Documento" } as Record<string, string>)[ctype]
      const next = prev.map((c) =>
        c.id === convId
          ? { ...c, last_message_at: temp.created_at, last_message_preview: preview, last_message_dir: "out" as const }
          : c
      )
      return next.sort(sortByLastMessage)
    })

    try {
      const fd = new FormData()
      fd.append("file", file)
      if (caption) fd.append("caption", caption)
      if (isVoiceNote) fd.append("ptt", "1")
      if (reply) fd.append("replyTo", reply.id)
      const result = await sendChatMedia(convId, fd)
      if ("error" in result) {
        // Falha tratada (ex: formato não aceito pelo WhatsApp Oficial) — bolha
        // marca "falhou" + toast claro, SEM crashar a UI (era o bug do re-throw).
        URL.revokeObjectURL(blobUrl)
        setActiveMessages((prev) =>
          prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m)
        )
        toast.error(result.error)
        return
      }
      // Swap id. Mantém blob URL até o próximo poll/realtime trazer o real
      // (com storage_path no metadata → resolveMediaUrl passa a usar /api/media/<id>).
      setActiveMessages((prev) =>
        prev.map((m) => m.id === temp.id ? { ...m, id: result.id, status: "sent" } : m)
      )
    } catch (err) {
      console.error("sendMedia:", err)
      URL.revokeObjectURL(blobUrl)
      setActiveMessages((prev) =>
        prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m)
      )
      toast.error("Não consegui enviar a mídia. Tente de novo.")
    }
  }, [makeTempMessage])

  const handleSendMedia = useCallback(
    (file: File, caption: string) => sendMediaInternal(file, caption, false),
    [sendMediaInternal],
  )

  const handleSendVoice = useCallback(
    (file: File) => sendMediaInternal(file, "", true),
    [sendMediaInternal],
  )

  // ── Citar / reagir / localização / contato ──────────────────
  const PREVIEW_BY_KIND: Record<string, string> = {
    image: "📷 Imagem", video: "🎥 Vídeo", audio: "🎧 Áudio", document: "📎 Documento",
    sticker: "Sticker", location: "📍 Localização", contact: "👤 Contato",
  }

  const handleReply = useCallback((msg: ChatMessage) => {
    if (!msg.whatsapp_msg_id) { toast.error("Aguarde a entrega da mensagem para responder."); return }
    const kind = msg.content_type
    const preview = (msg.content?.trim()) || PREVIEW_BY_KIND[kind] || "Mensagem"
    setReplyTarget({ id: msg.whatsapp_msg_id, preview: preview.slice(0, 200), kind })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleReact = useCallback(async (msg: ChatMessage, emoji: string) => {
    const convId = activeIdRef.current
    if (!convId || !msg.whatsapp_msg_id) { toast.error("Não dá pra reagir a essa mensagem ainda."); return }
    const fromMe = msg.sender_type !== "contact"
    const temp = makeTempMessage({ content: emoji, contentType: "reaction" })
    temp.metadata = { reacted_to_id: msg.whatsapp_msg_id }
    setActiveMessages((prev) => [...prev, temp])
    const result = await reactToMessage(convId, msg.whatsapp_msg_id, emoji, fromMe)
    if ("error" in result) {
      setActiveMessages((prev) => prev.filter((m) => m.id !== temp.id))
      toast.error(result.error)
      return
    }
    setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, id: result.id, status: "sent" } : m))
  }, [makeTempMessage])

  const handleSendLocation = useCallback(async (loc: { latitude: number; longitude: number; name?: string; address?: string }) => {
    const convId = activeIdRef.current
    if (!convId) return
    const temp = makeTempMessage({ content: `${loc.latitude},${loc.longitude}`, contentType: "location" })
    temp.metadata = { location_name: loc.name ?? null, location_address: loc.address ?? null }
    setActiveMessages((prev) => [...prev, temp])
    setConversations((prev) => prev.map((c) =>
      c.id === convId ? { ...c, last_message_at: temp.created_at, last_message_preview: "📍 Localização", last_message_dir: "out" as const } : c,
    ).sort(sortByLastMessage))
    const result = await sendLocationMessage(convId, loc)
    if ("error" in result) {
      setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m))
      toast.error(result.error)
      return
    }
    setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, id: result.id, status: "sent" } : m))
  }, [makeTempMessage])

  const handleSendContact = useCallback(async (card: { name: string; phone: string }) => {
    const convId = activeIdRef.current
    if (!convId) return
    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${card.name}\nTEL;type=CELL:${card.phone}\nEND:VCARD`
    const temp = makeTempMessage({ content: card.name, contentType: "contact" })
    temp.metadata = { contacts: [{ name: card.name, vcard }] }
    setActiveMessages((prev) => [...prev, temp])
    setConversations((prev) => prev.map((c) =>
      c.id === convId ? { ...c, last_message_at: temp.created_at, last_message_preview: "👤 Contato", last_message_dir: "out" as const } : c,
    ).sort(sortByLastMessage))
    const result = await sendContactMessage(convId, card)
    if ("error" in result) {
      setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m))
      toast.error(result.error)
      return
    }
    setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, id: result.id, status: "sent" } : m))
  }, [makeTempMessage])

  const handleSendSticker = useCallback(async (file: File) => {
    const convId = activeIdRef.current
    if (!convId) return
    const blobUrl = URL.createObjectURL(file)
    const temp = makeTempMessage({ content: null, contentType: "sticker", mediaUrl: blobUrl, mediaMime: "image/webp" })
    setActiveMessages((prev) => [...prev, temp])
    setConversations((prev) => prev.map((c) =>
      c.id === convId ? { ...c, last_message_at: temp.created_at, last_message_preview: "Figurinha", last_message_dir: "out" as const } : c,
    ).sort(sortByLastMessage))
    try {
      const fd = new FormData()
      fd.append("file", file)
      const result = await sendStickerMessage(convId, fd)
      if ("error" in result) {
        URL.revokeObjectURL(blobUrl)
        setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m))
        toast.error(result.error)
        return
      }
      setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, id: result.id, status: "sent" } : m))
    } catch {
      URL.revokeObjectURL(blobUrl)
      setActiveMessages((prev) => prev.map((m) => m.id === temp.id ? { ...m, status: "failed" } : m))
      toast.error("Não consegui enviar a figurinha.")
    }
  }, [makeTempMessage])

  const handleStatusChange = useCallback((status: string) => {
    if (!activeId) return
    startTransition(async () => {
      await updateConversationStatus(activeId, status)
      setConversations((prev) =>
        prev.map((c) => c.id === activeId ? { ...c, status: status as ChatConversation["status"] } : c)
      )
    })
  }, [activeId])

  // Follow-up marcado/cancelado no painel — a linha da lista muda no ATO (o chip não
  // espera o poll). O servidor já gravou; aqui é só espelhar.
  const handleFollowUpChange = useCallback((patch: Partial<ChatConversation>) => {
    if (!activeId) return
    setConversations((prev) => prev.map((c) => c.id === activeId ? { ...c, ...patch } : c))
  }, [activeId])

  const handleArchiveToggle = useCallback(() => {
    if (!activeId) return
    const conv = conversations.find((c) => c.id === activeId)
    if (!conv) return
    const willArchive = !conv.archived_at

    startTransition(async () => {
      try {
        if (willArchive) await archiveConversation(activeId)
        else             await unarchiveConversation(activeId)

        setConversations((prev) => {
          // Se arquivando e o filtro atual não é "apenas arquivadas", some da lista.
          // Se desarquivando e estamos em "apenas arquivadas", também some.
          // Em qualquer outro caso, atualiza o campo só.
          if (willArchive && !archivedOnly) {
            return prev.filter((c) => c.id !== activeId)
          }
          if (!willArchive && archivedOnly) {
            return prev.filter((c) => c.id !== activeId)
          }
          return prev.map((c) => c.id === activeId
            ? { ...c, archived_at: willArchive ? new Date().toISOString() : null }
            : c
          )
        })
        // Limpa seleção se a conv saiu da lista
        if ((willArchive && !archivedOnly) || (!willArchive && archivedOnly)) {
          setActiveId(null)
          setActiveMessages([])
        }
      } catch (err) {
        console.error("Erro ao arquivar:", err)
      }
    })
  }, [activeId, conversations, archivedOnly])

  // Transferência (header). Otimista: reflete dono/depto/participante na lista.
  const handleTransfer = useCallback(async (opts: TransferOpts) => {
    if (!activeId) return
    const result = await transferConversation(activeId, opts)
    if (result?.error) { toast.error(result.error); return }
    setConversations((prev) => prev.map((c) => {
      if (c.id !== activeId) return c
      let assigned_to    = c.assigned_to
      let department_id  = c.department_id
      if (opts.mode === "pool") {
        assigned_to = null; department_id = null
      } else if (opts.mode === "agent") {
        assigned_to   = opts.agentId ?? null
        const a       = agents.find((x) => x.id === opts.agentId)
        department_id = a?.department_id ?? c.department_id ?? null   // espelha o backend (herda; não limpa à toa)
      } else {
        department_id = opts.departmentId ?? null
        assigned_to   = opts.agentId ?? null
      }
      const participants = opts.stayAsParticipant && assigned_to !== currentUserId && !(c.participants ?? []).includes(currentUserId)
        ? [...(c.participants ?? []), currentUserId]
        : c.participants
      return { ...c, assigned_to, department_id, participants }
    }))
  }, [activeId, agents, currentUserId])

  // ── Ações do menu de contexto (por conversa, não só a ativa) ──
  const handleToggleFlag = useCallback((id: string, value: boolean) => {
    setConversations((prev) => prev.map((c) => c.id === id ? { ...c, flagged_pending: value } : c))
    startTransition(async () => { await setConversationFlagged(id, value) })
  }, [])

  const handleTogglePin = useCallback((id: string, value: boolean) => {
    setConversations((prev) => prev.map((c) => c.id === id ? { ...c, pinned_at: value ? new Date().toISOString() : null } : c))
    startTransition(async () => { await setConversationPinned(id, value) })
  }, [])

  const handleAssignMe = useCallback((id: string) => {
    setConversations((prev) => prev.map((c) => c.id === id ? { ...c, assigned_to: currentUserId } : c))
    startTransition(async () => { await assignConversation(id, currentUserId) })
  }, [currentUserId])

  // Tag toggle otimista (sidebar). Atualiza tagsByContact na hora; em falha,
  // reverte + toast. Sem revalidate do /inbox (ver applyTag/removeTag).
  const handleTagChange = useCallback((contactId: string, tagId: string, applied: boolean) => {
    const apply = (on: boolean) => setTagsByContact((prev) => {
      const cur = prev[contactId] ?? []
      const next = on
        ? (cur.includes(tagId) ? cur : [...cur, tagId])
        : cur.filter((id) => id !== tagId)
      return { ...prev, [contactId]: next }
    })
    apply(applied)  // otimista
    startTransition(async () => {
      try {
        if (applied) await applyTag(tagId, "contact", contactId)
        else         await removeTag(tagId, "contact", contactId)
      } catch {
        apply(!applied)  // rollback
        toast.error("Não consegui atualizar a tag. Tente de novo.")
      }
    })
  }, [])

  const handleArchiveFromMenu = useCallback((id: string) => {
    const willArchive = !archivedOnly  // na aba "arquivadas" a ação inverte
    setConversations((prev) => prev.filter((c) => c.id !== id))  // some da lista atual
    if (activeIdRef.current === id) { setActiveId(null); activeIdRef.current = null }
    startTransition(async () => {
      if (willArchive) await archiveConversation(id)
      else             await unarchiveConversation(id)
    })
  }, [archivedOnly])

  // Fixadas sobem pro topo (hoist client-side, ordem por pinned_at desc); o resto
  // mantém a ordem do server (last_message_at desc). Sort estável (ES2019+).
  const displayConversations = useMemo(() => {
    return [...conversations].sort((a, b) => {
      const pa = a.pinned_at ? new Date(a.pinned_at).getTime() : 0
      const pb = b.pinned_at ? new Date(b.pinned_at).getTime() : 0
      return pb - pa
    })
  }, [conversations])

  // Sem canal conectado → NÃO bloqueia o inbox: mostra a tela normal (lista vazia),
  // só desabilita "nova conversa" + um hint no topo. O Wizard "Vamos configurar seu
  // Kora" (modal de onboarding) é quem guia a conexão do canal.
  const channelReady = instanceStatus === "connected"

  return (
    <ConversationWorkflowProvider kanban={kanbanEnabled} agents={agents} departments={departments} onUnavailable={id => { setConversations(prev => prev.filter(c => c.id !== id)); if (activeId === id) { setActiveId(null); setActiveMessages([]); setContactSheetOpen(false) } void loadFirstPage() }} onUpdated={(result) => {
      setConversations(prev => prev.map(c => c.id === result.conversation.id ? { ...c, ...result.conversation, chat_contacts: c.chat_contacts && result.contact ? { ...c.chat_contacts, ...result.contact } : c.chat_contacts } : result.contact && c.chat_contacts && c.chat_contacts.id === result.contact.id ? { ...c, chat_contacts: { ...c.chat_contacts, ...result.contact } } : c))
      const contactId = result.contact?.id
      if (contactId) setTagsByContact(prev => ({ ...prev, [contactId]: result.tagIds }))
      if (pipelineFilter || tagFilter || statusFilter !== "all" || viewFilter !== "all") void loadFirstPage()
    }}>
    <div className="flex flex-col h-full overflow-hidden">
      {accessUnavailable && <div className="px-4 py-2 text-xs text-amber-800 bg-amber-50 border-b border-amber-200" role="status">Não foi possível confirmar seu acesso. As conversas ficam ocultas até a conexão ser restabelecida.</div>}
      {realtimeDown && (
        <div className="px-4 py-1.5 text-[11px] font-medium flex items-center gap-2 bg-amber-50 text-amber-700 border-b border-amber-200">
          <span className="size-1.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
          Reconectando ao tempo real… as mensagens continuam chegando normalmente.
        </div>
      )}
      {!channelReady && (
        <div className="px-4 py-2 text-xs font-medium flex items-center justify-between gap-2 bg-primary-50 text-primary-800 border-b border-primary-200">
          <span className="flex items-center gap-2 min-w-0">
            <span className="size-1.5 rounded-full bg-primary-500 shrink-0" />
            <span className="truncate">{instanceStatus === "disconnected" ? "Seu WhatsApp está desconectado — reconecte pra voltar a atender." : "Conecte um canal de WhatsApp pra começar a atender."}</span>
          </span>
          <Link href="/integracoes" className="font-semibold text-primary-700 hover:text-primary-800 underline underline-offset-2 shrink-0">
            {instanceStatus === "disconnected" ? "Reconectar" : "Conectar"}
          </Link>
        </div>
      )}
      {dedupNotice && (
        <div className={`px-4 py-2 text-xs font-medium flex items-center gap-2 border-b ${
          dedupNotice === "reopened"
            ? "bg-amber-50 text-amber-800 border-amber-200"
            : "bg-primary-50 text-primary-800 border-primary-200"
        }`}>
          {dedupNotice === "reopened"
            ? <>🔄 <strong>Conversa reaberta</strong> — esse contato já tinha conversa anterior. Estamos continuando ela.</>
            : <>💬 <strong>Conversa existente aberta</strong> — esse contato já estava em atendimento. Reusamos a conversa.</>}
        </div>
      )}
      <div className="flex flex-1 overflow-hidden">
        {/* Master (lista) — full-width no mobile; coluna fixa no desktop.
            Quando há conversa ativa no mobile, some pra dar lugar ao chat. */}
        <div className={`${activeId ? "hidden md:block" : "block"} w-full md:w-80 shrink-0`}>
          <ConversationList
            conversations={displayConversations}
            activeId={activeId}
            onSelect={handleSelect}
            currentUserId={currentUserId}
            onToggleFlag={handleToggleFlag}
            onTogglePin={handleTogglePin}
            onAssignMe={handleAssignMe}
            onArchive={handleArchiveFromMenu}
            viewFilter={viewFilter}
            onViewChange={setViewFilter}
            viewCounts={viewCounts}
            statusFilter={statusFilter}
            onStatusChange={setStatusFilter}
            channelFilter={channelFilter}
            onChannelFilterChange={setChannelFilter}
            pipelines={pipelines}
            stages={stages}
            tags={tags}
            departments={departments}
            tagsByContact={tagsByContact}
            showChannel={showChannel}
            officialChannel={officialChannel}
            channelReady={channelReady}
            agents={agents}
            // Filter state (lifted)
            searchValue={searchInput}
            onSearchChange={setSearchInput}
            pipelineFilter={pipelineFilter}
            onPipelineFilterChange={setPipelineFilter}
            agentFilter={agentFilter}
            onAgentFilterChange={setAgentFilter}
            departmentFilter={departmentFilter}
            onDepartmentFilterChange={setDepartmentFilter}
            tagFilter={tagFilter}
            onTagFilterChange={setTagFilter}
            staleOnly={staleOnly}
            onStaleOnlyChange={setStaleOnly}
            fromAd={fromAd}
            onFromAdChange={setFromAd}
            archivedOnly={archivedOnly}
            onArchivedOnlyChange={setArchivedOnly}
            // Paginação
            hasMore={hasMore}
            onLoadMore={loadMore}
            loadingMore={loadingMore}
            loadingList={loadingList}
          />
        </div>

        {/* Detail (chat) — escondido no mobile até abrir uma conversa; full-width
            quando ativo. No desktop é sempre a coluna principal. */}
        <div className={`${activeId ? "flex" : "hidden md:flex"} relative flex-1 min-w-0 overflow-hidden`}>
          {activeConv ? (
            <>
              <div className="flex-1 min-w-0">
                <ChatPanel
                  conversation={activeConv}
                  pipelines={pipelines}
                  stages={stages}
                  messages={activeMessages}
                  quickReplies={quickReplies}
                  agents={agents}
                  departments={departments}
                  onStatusChange={handleStatusChange}
                  onFollowUpChange={handleFollowUpChange}
                  onTransfer={handleTransfer}
                  hasMoreOlder={hasMoreOlder}
                  loadingOlder={loadingOlder}
                  onLoadOlder={loadOlderMessages}
                  loadingMessages={loadingMsg}
                  onSendText={handleSendText}
                  onSendMedia={handleSendMedia}
                  onSendVoice={handleSendVoice}
                  onReply={handleReply}
                  onReact={handleReact}
                  onSendLocation={handleSendLocation}
                  onSendContact={handleSendContact}
                  onSendSticker={handleSendSticker}
                  replyTarget={replyTarget}
                  onCancelReply={() => setReplyTarget(null)}
                  onArchiveToggle={handleArchiveToggle}
                  onBack={() => { setActiveId(null); setActiveMessages([]); setContactSheetOpen(false) }}
                  onOpenContact={() => setContactSheetOpen(true)}
                  agendaEnabled={agendaEnabled}
                />
              </div>
              {activeConv.chat_contacts && (
                <>
                  <ContactDetailsOverlay
                    open={contactSheetOpen}
                    onClose={() => setContactSheetOpen(false)}
                    conversation={activeConv}
                    contact={activeConv.chat_contacts}
                    pipelines={pipelines}
                    stages={stages}
                    tags={tags}
                    tagsByContact={tagsByContact}
                    onTagChange={handleTagChange}
                    onParticipantsChange={(id, participants, stillVisible) => {
                      if (!stillVisible) {
                        accessEpochRef.current++
                        setConversations(prev => prev.filter(c => c.id !== id))
                        if (activeIdRef.current === id) {
                          activeIdRef.current = null
                          setActiveId(null); setActiveMessages([]); setReplyTarget(null); setContactSheetOpen(false)
                        }
                        toast.info("Você saiu da conversa e não tem outro vínculo de acesso.")
                      } else setConversations(prev => prev.map(c => c.id === id ? { ...c, participants } : c))
                    }}
                    agents={agents}
                    externalAdReply={activeAdReply}
                  />
                </>
              )}
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center bg-slate-50">
              <MessageCircle className="size-14 text-slate-200 mb-4" />
              <p className="text-sm font-medium text-slate-500 mb-1">
                Selecione uma conversa
              </p>
              <p className="text-xs text-slate-400">
                Escolha uma conversa ao lado para começar o atendimento.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
    </ConversationWorkflowProvider>
  )
}
